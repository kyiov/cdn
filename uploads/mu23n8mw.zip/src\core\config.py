"""Config loader: baca config.toml, resolve cross-platform paths."""
import os
import sys
import tomllib
import platformdirs

# Project root = parent dari src/ (yaitu folder budycn/)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CONFIG_PATH = os.path.join(PROJECT_ROOT, "config.toml")
DATA_DIR = os.path.join(PROJECT_ROOT, "data")

# Cache config setelah load pertama
_cfg = None


def load_config():
    """Load config.toml, return dict. Cache hasilnya."""
    global _cfg
    if _cfg is not None:
        return _cfg
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError(f"config.toml not found at {CONFIG_PATH}")
    with open(CONFIG_PATH, "rb") as f:
        _cfg = tomllib.load(f)
    return _cfg


def get_config():
    """Alias untuk load_config()."""
    return load_config()


def get_5sim_jwt():
    return load_config()["5sim"]["jwt"]


def get_proxies():
    """Return list proxy dari config.toml."""
    return load_config().get("proxies", [])


def get_bot_settings():
    """Return [bot] section."""
    return load_config().get("bot", {})


def get_router_settings():
    """Return [bot.router] section."""
    bot = load_config().get("bot", {})
    return bot.get("router", {})


def find_db_path():
    """Cari 9router SQLite database cross-platform.

    Returns path jika ditemukan, None jika tidak.
    """
    candidates = []

    # 1. Dari config.toml
    router = get_router_settings()
    config_path = router.get("db_path", "")
    if config_path:
        candidates.append(os.path.expanduser(config_path))

    # 2. platformdirs (user_data_dir)
    #    Windows: C:\Users\<user>\AppData\Local\9router
    #    Linux:   ~/.local/share/9router
    #    macOS:   ~/Library/Application Support/9router
    try:
        data_dir = platformdirs.user_data_dir("9router", appauthor=False)
        candidates.append(os.path.join(data_dir, "db", "data.sqlite"))
    except Exception:
        pass

    # 3. Windows AppData\Roaming
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            candidates.append(os.path.join(appdata, "9router", "db", "data.sqlite"))

    # 4. Linux custom paths
    if sys.platform != "win32":
        for base in ["~/.9router", "~/.config/9router", "~/.local/share/9router"]:
            candidates.append(os.path.join(os.path.expanduser(base), "db", "data.sqlite"))

    # 5. macOS
    if sys.platform == "darwin":
        candidates.append(os.path.expanduser("~/Library/Application Support/9router/db/data.sqlite"))

    # Check existing
    for p in candidates:
        if os.path.exists(p):
            return p

    return None


def get_data_file(filename):
    """Return path ke file di data/ directory."""
    return os.path.join(DATA_DIR, filename)