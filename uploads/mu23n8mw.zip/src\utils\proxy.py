"""Proxy checker: test connectivity & latency."""
import time
import requests
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings()


def check_proxy(proxy_dict, timeout=8):
    """Test satu proxy.

    Args:
        proxy_dict: {'label': 'CN-1', 'type': 'http', 'host': '...', 'port': ..., 'username': '...', 'password': '...'}
        timeout: timeout dalam detik

    Returns:
        dict: {label, working, ip, latency_ms, error, codebuddy_cn_reachable}
    """
    label = proxy_dict.get("label", "unknown")
    proxy_type = proxy_dict.get("type", "http")
    host = proxy_dict.get("host", "")
    port = proxy_dict.get("port", 80)
    username = proxy_dict.get("username", "")
    password = proxy_dict.get("password", "")

    # Build proxy URL
    auth = f"{username}:{password}@" if username and password else ""
    proxy_url = f"{proxy_type}://{auth}{host}:{port}"
    proxies = {"http": proxy_url, "https": proxy_url}

    result = {
        "label": label,
        "working": False,
        "ip": None,
        "latency_ms": None,
        "error": None,
        "codebuddy_cn_reachable": False,
    }

    # Test 1: httpbin.org (cek external IP + latency) — pakai HTTP biar semua proxy bisa
    try:
        start = time.monotonic()
        r = requests.get("http://httpbin.org/ip", proxies=proxies, timeout=timeout)
        elapsed = (time.monotonic() - start) * 1000
        if r.status_code == 200:
            result["working"] = True
            result["ip"] = r.json().get("origin", "unknown")
            result["latency_ms"] = round(elapsed, 1)
    except requests.exceptions.Timeout:
        result["error"] = "Timeout"
    except requests.exceptions.ProxyError as e:
        result["error"] = f"ProxyError: {str(e)[:80]}"
    except requests.exceptions.ConnectionError:
        result["error"] = "Connection refused"
    except Exception as e:
        result["error"] = str(e)[:80]

    # Test 2: codebuddy.cn (cek bisa reach CN)
    if result["working"]:
        try:
            r2 = requests.get("https://www.codebuddy.cn", proxies=proxies, timeout=timeout, verify=False)
            result["codebuddy_cn_reachable"] = r2.status_code == 200
        except Exception:
            result["codebuddy_cn_reachable"] = False

    return result


def check_all_proxies(proxy_list, max_workers=5):
    """Test semua proxy concurrently.

    Returns:
        list[dict]: hasil check_proxy untuk setiap proxy
    """
    if not proxy_list:
        return []

    results = []
    with ThreadPoolExecutor(max_workers=min(max_workers, len(proxy_list))) as executor:
        futures = {executor.submit(check_proxy, p): p for p in proxy_list}
        for future in as_completed(futures):
            try:
                results.append(future.result())
            except Exception as e:
                p = futures[future]
                results.append({
                    "label": p.get("label", "unknown"),
                    "working": False,
                    "ip": None,
                    "latency_ms": None,
                    "error": str(e)[:80],
                    "codebuddy_cn_reachable": False,
                })

    # Sort by label
    results.sort(key=lambda r: r["label"])
    return results