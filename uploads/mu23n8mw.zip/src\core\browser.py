"""Playwright headless browser automation: login flow CodeBuddy.cn."""
import os
import re
import time
import json
from playwright.sync_api import sync_playwright, TimeoutError as PwTimeout

from .config import get_bot_settings, PROJECT_ROOT
from .auth import build_keycloak_url


def run_login_flow(phone, country_code, local_number, order_id, state, fivesim, debug=False):
    """Jalankan login flow CodeBuddy.cn via Keycloak SMS OTP.

    Args:
        phone: full phone number (+852...)
        country_code: kode negara (e.g. "852")
        local_number: nomor local tanpa kode negara
        order_id: 5SIM order ID
        state: state token dari get_state()
        fivesim: FiveSimClient instance
        debug: kalau True, save screenshots

    Returns:
        bool: True jika login flow berhasil, False jika gagal
    """
    settings = get_bot_settings()
    headless = settings.get("headless", True)
    debug = debug or settings.get("debug", False)

    keycloak_url = build_keycloak_url(state)
    otp_code = None

    with sync_playwright() as pw:
        browser = pw.chromium.launch(
            headless=headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-gpu",
                "--window-size=1920,1080",
            ],
        )
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            viewport={"width": 1280, "height": 800},
            locale="zh-CN",
        )
        page = context.new_page()

        if debug:
            def on_response(resp):
                url = resp.url
                if any(kw in url for kw in ["token", "auth/login", "auth/state", "plugin"]):
                    try:
                        body = resp.json()
                        print(f"  [NET] {resp.status} {url[:100]} -> {json.dumps(body)[:150]}")
                    except Exception:
                        pass
            page.on("response", on_response)

        try:
            # --- 3a: Buka Keycloak ---
            if debug:
                print("    Opening Keycloak...")
            page.goto(keycloak_url, wait_until="networkidle", timeout=30000)
            page.wait_for_timeout(2000)

            if debug:
                page.screenshot(path=os.path.join(PROJECT_ROOT, "debug_01_keycloak.png"))

            # --- 3a2: Pilih country code ---
            country_sel = page.locator(".kc-country-selector")
            if country_sel.count() > 0:
                country_sel.first.click()
                page.wait_for_timeout(500)
                country_option = page.locator(f".kc-country-option:has-text('+{country_code}')")
                if country_option.count() > 0:
                    country_option.first.click()
                else:
                    all_opts = page.locator(".kc-country-option")
                    for i in range(min(all_opts.count(), 10)):
                        txt = (all_opts.nth(i).text_content() or "").strip()
                        if country_code in txt:
                            all_opts.nth(i).click()
                            break
            page.wait_for_timeout(300)

            if debug:
                page.screenshot(path=os.path.join(PROJECT_ROOT, "debug_01b_country.png"))

            # --- 3b: Isi phone ---
            phone_sel = page.locator("input#phoneNumber[type='text']")
            phone_sel.wait_for(state="visible", timeout=10000)
            phone_sel.fill(local_number)

            # --- 3c: Klik send SMS ---
            page.wait_for_timeout(500)
            send_btn = page.locator("input.code-btn")
            try:
                send_btn.wait_for(state="visible", timeout=5000)
                send_btn.click()
            except PwTimeout:
                btns = page.locator("input[type='button']")
                clicked = False
                for i in range(min(btns.count(), 10)):
                    val = (btns.nth(i).get_attribute("value") or "").strip()
                    if any(kw in val for kw in ["验证码", "获取", "send", "code"]):
                        btns.nth(i).click()
                        clicked = True
                        break
                if not clicked:
                    raise RuntimeError("Send SMS button not found")

            if debug:
                page.screenshot(path=os.path.join(PROJECT_ROOT, "debug_03_sent.png"))
            page.wait_for_timeout(3000)

            # --- 3d: Tunggu OTP dari 5SIM ---
            start = time.time()
            while time.time() - start < 90:
                try:
                    resp = fivesim.check_otp(order_id)
                    if resp.get("sms"):
                        otp_code = resp["sms"][0].get("code")
                        if debug:
                            print(f"    OTP: {otp_code}")
                        break
                    st = resp.get("status", "")
                    if st in ("CANCELED", "TIMEOUT", "BANNED"):
                        if debug:
                            print(f"    Order status: {st}")
                        break
                except Exception as e:
                    if debug:
                        print(f"    Poll error: {e}")
                if debug:
                    print(f"    ... waiting ({int(time.time() - start)}s)")
                time.sleep(4)

            if not otp_code:
                fivesim.cancel_order(order_id)
                return None, None, None

            # --- 3e: Isi OTP ---
            otp_sel = page.locator("input#code")
            otp_sel.wait_for(state="visible", timeout=5000)
            otp_sel.fill(otp_code)

            if debug:
                page.screenshot(path=os.path.join(PROJECT_ROOT, "debug_04_otp_filled.png"))

            # --- 3f: Submit login ---
            page.wait_for_timeout(500)
            submit_btn = page.locator("input#kc-login")
            submit_btn.wait_for(state="visible", timeout=5000)
            for _ in range(10):
                disabled = submit_btn.get_attribute("disabled")
                if disabled is None:
                    break
                page.wait_for_timeout(1000)
            submit_btn.click()

            # --- 3f2: Check hasil submit ---
            page.wait_for_timeout(4000)
            post_url = page.url

            # Deteksi error
            error_selectors = [
                ".kc-feedback-text", ".alert-error", ".pf-m-danger",
                "#kc-error-message", ".kc-alert", "[class*='error']",
                "[class*='alert']", ".help-block", ".invalid-feedback",
                "#input-error", ".pf-c-alert", ".pf-c-form__alert",
            ]
            has_error = False
            for sel in error_selectors:
                try:
                    el = page.locator(sel)
                    if el.count() > 0 and el.first.is_visible():
                        txt = (el.first.text_content() or "").strip()
                        if txt and len(txt) > 2:
                            if debug:
                                print(f"    ERROR [{sel}]: {txt[:200]}")
                            has_error = True
                except Exception:
                    pass

            if has_error:
                if debug:
                    page.screenshot(path=os.path.join(PROJECT_ROOT, "debug_error.png"))
                fivesim.cancel_order(order_id)
                return None, None, None

            # Still on authenticate page?
            if "authenticate" in post_url or "login-actions" in post_url:
                if debug:
                    print("    WARNING: Still on authenticate page!")
                    with open(os.path.join(PROJECT_ROOT, "debug_authenticate.html"), "w", encoding="utf-8") as f:
                        f.write(page.content())
                otp_retry = page.locator("input#code")
                if otp_retry.count() > 0 and otp_retry.first.is_visible():
                    fivesim.cancel_order(order_id)
                    return None, None, None
                body_text = (page.locator("body").text_content() or "").lower()
                for kw in ["invalid", "expired", "incorrect", "wrong", "try again", "error", "failed", "失败", "错误", "无效", "过期"]:
                    if kw in body_text:
                        fivesim.cancel_order(order_id)
                        return None, None, None

            # --- 3g: Tunggu redirect ---
            for i in range(20):
                page.wait_for_timeout(2000)
                url = page.url
                if "codebuddy.cn" in url and "/login" not in url.split("?")[0]:
                    break
                if "authenticate" not in url and "login-actions" not in url:
                    if "/login" in url:
                        page.wait_for_timeout(3000)
                        break

            if debug:
                page.screenshot(path=os.path.join(PROJECT_ROOT, "debug_06_after_login.png"))

        except Exception as e:
            if debug:
                print(f"    FATAL: {e}")
                try:
                    page.screenshot(path=os.path.join(PROJECT_ROOT, "debug_FATAL.png"))
                except Exception:
                    pass
            try:
                fivesim.cancel_order(order_id)
            except Exception:
                pass
            raise
        finally:
            browser.close()

    # Return success — token didapat via polling (di caller)
    return True