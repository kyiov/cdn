"""Created by: anthropic_autogen
Creation timestamp: 2026-08-21 22:35
Description: CLI interactive menu & routing untuk cbcn-automation.
"""
import os
import json
import time
from rich.prompt import Prompt, Confirm, IntPrompt

from ..core.config import get_config, get_bot_settings, get_router_settings, find_db_path, get_data_file
from ..core.fivesim import FiveSimClient
from ..core.auth import get_state, poll_token
from ..core.browser import run_login_flow
from ..db.inject import inject_token, list_connections
from ..utils.proxy import check_all_proxies
from .ui import (
    print_banner, print_balance, print_price, print_proxy_status,
    print_account_summary, print_tokens, create_progress,
    print_success, print_error, print_info, print_settings,
    print_menu, console,
)


def menu_balance():
    """Menu: Check balance."""
    fivesim = FiveSimClient()
    try:
        bal = fivesim.get_balance()
        print_balance(bal)

        # Juga tampilkan harga
        price = fivesim.get_price("hongkong", "codebuddy")
        print_price(price)
    except Exception as e:
        print_error(f"Failed to check balance: {e}")


def menu_proxy():
    """Menu: Check all proxies."""
    cfg = get_config()
    proxies = cfg.get("proxies", [])
    if not proxies:
        print_info("No proxies configured in config.toml")
        return

    print_info(f"Testing {len(proxies)} proxy(s)...")
    results = check_all_proxies(proxies)
    print_proxy_status(results)

    working = [r for r in results if r["working"]]
    cn_ok = [r for r in working if r["codebuddy_cn_reachable"]]
    print_info(f"Working: {len(working)}/{len(proxies)} | CN reachable: {len(cn_ok)}/{len(proxies)}")


def _create_single_account(fivesim_client, debug=False):
    """Create one account. Returns dict dengan hasil."""
    bal = fivesim_client.get_balance()
    bal_amount = float(bal["balance"])

    if bal_amount < 0.13:
        return {"phone": "N/A", "status": "FAIL", "error": "Insufficient balance"}

    # Buy number
    order = fivesim_client.buy_number()
    oid = order["id"]
    phone_raw = order["phone"]
    phone = "+" + phone_raw.lstrip("+")
    phone_clean = phone.lstrip("+")
    country_code = phone_clean[:3] if phone_clean.startswith("852") else phone_clean[:2]
    local_number = phone_clean[len(country_code):]

    print_info(f"Phone: {phone} | Order: {oid} | Price: ${order['price']}")

    # Get state
    state, _ = get_state()

    # Run browser login flow
    print_info("Running browser login flow...")
    try:
        success = run_login_flow(
            phone=phone,
            country_code=country_code,
            local_number=local_number,
            order_id=oid,
            state=state,
            fivesim=fivesim_client,
            debug=debug,
        )

        if not success:
            return {"phone": phone, "status": "FAIL", "error": "Login flow failed"}

        # Poll token
        print_info("Polling token...")
        token = poll_token(state)
        if not token:
            fivesim_client.cancel_order(oid)
            return {"phone": phone, "status": "FAIL", "error": "Token polling timeout"}

        # Inject ke 9router
        ok, conn_id = inject_token(phone, token["accessToken"], token["refreshToken"], token["expiresIn"])
        if ok:
            print_success(f"Injected to 9router: {conn_id}")
        else:
            print_info("9router DB not found, skipping injection")

        # Save token ke file
        _save_token(phone, state, token)

        # Finish order
        fivesim_client.finish_order(oid)
        print_success(f"Account created: {phone}")
        return {"phone": phone, "status": "OK", "error": None}

    except Exception as e:
        try:
            fivesim_client.cancel_order(oid)
        except Exception:
            pass
        return {"phone": phone, "status": "FAIL", "error": str(e)[:100]}


def menu_create():
    """Menu: Create single account."""
    fivesim = FiveSimClient()

    # Tampilkan saldo dulu
    try:
        bal = fivesim.get_balance()
        print_balance(bal)
    except Exception as e:
        print_error(f"Cannot check balance: {e}")
        return

    confirm = Confirm.ask("Create one account?", default=True)
    if not confirm:
        return

    result = _create_single_account(fivesim, debug=False)
    if result["status"] == "OK":
        print_success(f"Done! Account: {result['phone']}")
    else:
        print_error(f"Failed: {result['error']}")


def menu_batch():
    """Menu: Batch create accounts."""
    fivesim = FiveSimClient()

    # Tampilkan saldo
    try:
        bal = fivesim.get_balance()
        bal_amount = float(bal["balance"])
        print_balance(bal)
    except Exception as e:
        print_error(f"Cannot check balance: {e}")
        return

    max_accounts = int(bal_amount // 0.13)
    print_info(f"Balance: ${bal_amount} — max ~{max_accounts} accounts (@ $0.13 each)")

    count = IntPrompt.ask("How many accounts?", default=1, show_default=True)
    if count <= 0:
        return

    estimated = count * 0.13
    confirm = Confirm.ask(
        f"Create [bold]{count}[/bold] account(s)? Estimated cost: [yellow]${estimated:.2f}[/yellow]",
        default=True,
    )
    if not confirm:
        return

    results = []

    with create_progress() as progress:
        task = progress.add_task("[cyan]Creating accounts...", total=count)

        for i in range(count):
            # Re-init client tiap iterasi (fresh session)
            client = FiveSimClient()
            try:
                result = _create_single_account(client, debug=False)
                results.append(result)
            except Exception as e:
                results.append({"phone": "N/A", "status": "FAIL", "error": str(e)[:100]})

            progress.update(task, advance=1)

    # Summary
    print_account_summary(results)

    # Final balance
    try:
        final_bal = fivesim.get_balance()
        print_info(f"Final balance: ${final_bal['balance']}")
    except Exception:
        pass


def menu_tokens():
    """Menu: View saved tokens."""
    token_file = get_data_file("oauth_tokens.json")
    if not os.path.exists(token_file):
        print_info("No tokens file found.")
        return

    with open(token_file, "r", encoding="utf-8") as f:
        try:
            tokens = json.load(f)
        except json.JSONDecodeError:
            tokens = []

    if not isinstance(tokens, list):
        tokens = [tokens]

    print_tokens(tokens)


def menu_settings():
    """Menu: Show settings."""
    cfg = get_config()

    # Build flat settings dict
    settings = {
        "5sim.jwt": cfg.get("5sim", {}).get("jwt", "")[:30] + "...",
        "proxies": [p.get("label", "?") for p in cfg.get("proxies", [])],
        "bot.country": get_bot_settings().get("country", "N/A"),
        "bot.service": get_bot_settings().get("service", "N/A"),
        "bot.headless": get_bot_settings().get("headless", True),
        "bot.debug": get_bot_settings().get("debug", False),
        "bot.target_keys": get_bot_settings().get("target_keys", 10),
        "bot.router.provider": get_router_settings().get("provider", "N/A"),
        "bot.router.db_path": get_router_settings().get("db_path", "N/A"),
    }

    # DB path resolved
    db_path = find_db_path()
    settings["db.resolved"] = db_path or "[red]NOT FOUND[/red]"

    print_settings(settings)


def _save_token(phone, state, token):
    """Save token ke oauth_tokens.json (append)."""
    token_file = get_data_file("oauth_tokens.json")

    if os.path.exists(token_file):
        with open(token_file, "r", encoding="utf-8") as f:
            try:
                all_tokens = json.load(f)
            except json.JSONDecodeError:
                all_tokens = []
        if not isinstance(all_tokens, list):
            all_tokens = [all_tokens] if all_tokens else []
    else:
        all_tokens = []

    all_tokens.append({
        "phone": phone,
        "state": state,
        "accessToken": token["accessToken"],
        "refreshToken": token["refreshToken"],
        "expiresIn": token["expiresIn"],
    })

    with open(token_file, "w", encoding="utf-8") as f:
        json.dump(all_tokens, f, indent=2, ensure_ascii=False)


def run_interactive():
    """Jalankan interactive menu loop."""
    import os

    menu_items = {
        "1": ("Check Balance", menu_balance),
        "2": ("Check Proxies", menu_proxy),
        "3": ("Create Account", menu_create),
        "4": ("Batch Create", menu_batch),
        "5": ("View Tokens", menu_tokens),
        "6": ("Settings", menu_settings),
        "7": ("Exit", None),
    }

    while True:
        # Clear screen
        import os
        os.system("cls" if os.name == "nt" else "clear")
        print_banner()

        # Print menu dalam Rich Panel box
        print_menu(menu_items)

        choice = Prompt.ask("Select option", choices=list(menu_items.keys()), default="1")

        if choice == "7":
            console.print()
            print_info("Goodbye!")
            break

        _, handler = menu_items[choice]
        if handler:
            console.print()
            handler()
            console.print()
            Prompt.ask("[dim]Press Enter to continue[/dim]", default="", show_default=False)