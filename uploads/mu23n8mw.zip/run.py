#!/usr/bin/env python3
"""cbcn-automation — CodeBuddy.cn Account Creator CLI

Usage:
    python run.py                  # Interactive menu
    python run.py balance          # Check 5SIM balance
    python run.py proxy            # Test all proxies
    python run.py create           # Create single account
    python run.py batch --count N  # Batch create N accounts
    python run.py tokens           # View saved tokens
    python run.py settings         # Show configuration
"""
import sys
import os
import argparse

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.cli.app import (
    run_interactive, menu_balance, menu_proxy, menu_create,
    menu_batch, menu_tokens, menu_settings,
)


def main():
    parser = argparse.ArgumentParser(
        description="cbcn-automation — CodeBuddy.cn Account Creator",
        prog="run.py",
    )
    sub = parser.add_subparsers(dest="command", help="Commands")

    sub.add_parser("balance", help="Check 5SIM balance")
    sub.add_parser("proxy", help="Test all proxies")
    sub.add_parser("create", help="Create single account")
    sub.add_parser("tokens", help="View saved tokens")
    sub.add_parser("settings", help="Show configuration")

    batch_parser = sub.add_parser("batch", help="Batch create accounts")
    batch_parser.add_argument("--count", "-c", type=int, default=None, help="Number of accounts to create")

    args = parser.parse_args()

    if args.command == "balance":
        menu_balance()
    elif args.command == "proxy":
        menu_proxy()
    elif args.command == "create":
        menu_create()
    elif args.command == "batch":
        if args.count:
            # Override target_keys untuk batch via CLI
            import src.cli.app as app
            orig_batch = app.menu_batch

            def batch_with_count():
                """Batch with count from CLI arg."""
                from src.core.fivesim import FiveSimClient
                from src.cli.ui import print_balance, print_info, print_account_summary, create_progress, print_success

                fivesim = FiveSimClient()
                try:
                    bal = fivesim.get_balance()
                    print_balance(bal)
                except Exception as e:
                    print(f"Error: {e}")
                    return

                count = args.count
                estimated = count * 0.13
                print_info(f"Creating {count} account(s) — estimated cost: ${estimated:.2f}")

                results = []
                with create_progress() as progress:
                    task = progress.add_task("[cyan]Creating accounts...", total=count)
                    for i in range(count):
                        client = FiveSimClient()
                        try:
                            result = app._create_single_account(client, debug=False)
                            results.append(result)
                        except Exception as e:
                            results.append({"phone": "N/A", "status": "FAIL", "error": str(e)[:100]})
                        progress.update(task, advance=1)

                print_account_summary(results)
                try:
                    final_bal = fivesim.get_balance()
                    print_info(f"Final balance: ${final_bal['balance']}")
                except Exception:
                    pass

            batch_with_count()
        else:
            menu_batch()
    elif args.command == "tokens":
        menu_tokens()
    elif args.command == "settings":
        menu_settings()
    else:
        run_interactive()


if __name__ == "__main__":
    # Fix encoding
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    main()