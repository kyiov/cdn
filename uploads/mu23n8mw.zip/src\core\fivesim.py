"""5SIM API client: balance, buy number, check OTP, cancel, finish."""
import requests
from .config import get_5sim_jwt


class FiveSimClient:
    """Client untuk 5SIM.net API."""

    BASE = "https://5sim.net/v1"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {get_5sim_jwt()}",
            "Accept": "application/json",
        })

    def get_balance(self):
        """GET /v1/user/profile — return full JSON."""
        r = self.session.get(f"{self.BASE}/user/profile", timeout=15)
        r.raise_for_status()
        return r.json()

    def get_price(self, country="hongkong", service="codebuddy"):
        """GET /v1/guest/prices — cek harga & stock."""
        r = self.session.get(f"{self.BASE}/guest/prices?country={country}", timeout=15)
        data = r.json()
        return data.get(service, {})

    def buy_number(self, country="hongkong", service="codebuddy"):
        """GET /v1/user/buy/activation/{country}/any/{service} — beli nomor."""
        r = self.session.get(
            f"{self.BASE}/user/buy/activation/{country}/any/{service}",
            timeout=30,
        )
        r.raise_for_status()
        return r.json()

    def check_otp(self, order_id):
        """GET /v1/user/check/{order_id} — poll SMS."""
        r = self.session.get(f"{self.BASE}/user/check/{order_id}", timeout=15)
        r.raise_for_status()
        return r.json()

    def cancel_order(self, order_id):
        """GET /v1/user/cancel/{order_id} — cancel & refund."""
        r = self.session.get(f"{self.BASE}/user/cancel/{order_id}", timeout=15)
        r.raise_for_status()
        return r.json()

    def finish_order(self, order_id):
        """GET /v1/user/finish/{order_id} — mark complete."""
        r = self.session.get(f"{self.BASE}/user/finish/{order_id}", timeout=15)
        r.raise_for_status()
        return r.json()

    def get_active_orders(self):
        """GET /v1/user/orders — list active orders."""
        r = self.session.get(
            f"{self.BASE}/user/orders?category=activation&limit=10",
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
        return [o for o in data.get("data", []) if o.get("status") in ("PENDING", "RECEIVED")]