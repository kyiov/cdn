"""CodeBuddy.cn OAuth helpers: get state, poll token."""
import time
import requests
import urllib3
from urllib.parse import urlencode

urllib3.disable_warnings()

HEADERS = {
    "User-Agent": "CLI/2.108.1 CodeBuddy/2.108.1",
    "X-Product": "SaaS",
    "X-IDE-Type": "CLI",
    "X-IDE-Name": "CLI",
    "X-Requested-With": "XMLHttpRequest",
    "X-Codebuddy-Request": "1",
    "X-Domain": "copilot.tencent.com",
    "X-No-Authorization": "true",
    "X-No-User-Id": "true",
    "Content-Type": "application/json",
}


def get_state():
    """POST /v2/plugin/auth/state?platform=CLI — dapatkan state token & authUrl.

    Returns:
        tuple: (state, auth_url)
    """
    s = requests.Session()
    s.verify = False
    s.headers.update(HEADERS)

    r = s.post(
        "https://copilot.tencent.com/v2/plugin/auth/state?platform=CLI",
        json={},
        timeout=15,
    )
    data = r.json()
    if data.get("code") != 0:
        raise RuntimeError(f"Failed to get state: {data.get('msg', 'unknown')}")

    state = data["data"]["state"]
    auth_url = data["data"]["authUrl"]
    return state, auth_url


def build_keycloak_url(state):
    """Build Keycloak auth URL untuk CodeBuddy.cn."""
    return (
        "https://www.codebuddy.cn/auth/realms/copilot/protocol/openid-connect/auth?"
        + urlencode({
            "client_id": "console",
            "redirect_uri": f"https://www.codebuddy.cn/login/?platform=CLI&state={state}",
            "response_type": "code",
            "scope": "openid",
        })
    )


def poll_token(state, max_attempts=25, interval=5):
    """Poll GET /v2/plugin/auth/token?state=... sampai dapat token.

    Args:
        state: state token dari get_state()
        max_attempts: maksimal polling attempts
        interval: jeda antar poll (detik)

    Returns:
        dict: {accessToken, refreshToken, expiresIn} atau None jika timeout
    """
    s = requests.Session()
    s.verify = False
    s.headers.update({
        **HEADERS,
        "X-No-Enterprise-Id": "true",
        "X-No-Department-Info": "true",
        "Accept": "application/json",
    })

    for i in range(max_attempts):
        r = s.get(
            "https://copilot.tencent.com/v2/plugin/auth/token",
            params={"state": state},
            timeout=10,
        )
        data = r.json()
        code = data.get("code", -1)

        if code == 0 and data.get("data", {}).get("accessToken"):
            d = data["data"]
            return {
                "accessToken": d["accessToken"],
                "refreshToken": d.get("refreshToken", ""),
                "expiresIn": d.get("expiresIn", 86400),
            }
        elif code == 11217:
            # authorization_pending — lanjut poll
            pass
        else:
            # Unknown error
            pass

        if i < max_attempts - 1:
            time.sleep(interval)

    return None