"""9router SQLite database injection."""
import os
import json
import sqlite3
import uuid
from datetime import datetime

from ..core.config import find_db_path


def get_db_path():
    """Cari & return path ke 9router data.sqlite."""
    return find_db_path()


def inject_token(phone, access_token, refresh_token, expires_in):
    """Inject OAuth token ke 9router providerConnections table.

    Args:
        phone: nomor telepon (untuk nama connection)
        access_token: JWT access token
        refresh_token: JWT refresh token
        expires_in: durasi token dalam detik

    Returns:
        tuple: (success: bool, connection_id: str | None)
    """
    db_path = get_db_path()
    if not db_path or not os.path.exists(db_path):
        return False, None

    conn = sqlite3.connect(db_path)
    conn.text_factory = lambda x: x.decode('utf-8', errors='replace')
    c = conn.cursor()

    new_id = str(uuid.uuid4())
    now = datetime.now().isoformat() + "Z"
    exp = expires_in or 86400
    expires_at = datetime.fromtimestamp(datetime.now().timestamp() + exp).isoformat() + "Z"

    data = json.dumps({
        "accessToken": access_token,
        "refreshToken": refresh_token,
        "expiresAt": expires_at,
        "expiresIn": exp,
        "scope": "openid",
        "providerSpecificData": {
            "connectionProxyEnabled": False,
            "connectionProxyUrl": "",
            "connectionNoProxy": "",
        },
    })

    c.execute(
        """INSERT INTO providerConnections
           (id, provider, authType, name, email, priority, isActive, data, createdAt, updatedAt)
           VALUES (?, 'codebuddy-cn', 'oauth', ?, NULL, 1, 1, ?, ?, ?)""",
        (new_id, f"Account {phone}", data, now, now),
    )
    conn.commit()
    conn.close()

    return True, new_id


def list_connections():
    """List semua codebuddy-cn connections di 9router."""
    db_path = get_db_path()
    if not db_path or not os.path.exists(db_path):
        return []

    conn = sqlite3.connect(db_path)
    conn.text_factory = lambda x: x.decode('utf-8', errors='replace')
    c = conn.cursor()

    c.execute(
        "SELECT id, provider, authType, name, createdAt FROM providerConnections "
        "WHERE provider='codebuddy-cn' ORDER BY createdAt DESC"
    )
    rows = c.fetchall()
    conn.close()

    return [
        {"id": r[0], "provider": r[1], "authType": r[2], "name": r[3], "createdAt": r[4]}
        for r in rows
    ]