# BUDYCN — CodeBuddy.cn Account Creator

Bot otomatis untuk membuat akun CodeBuddy.cn menggunakan virtual phone number dari 5SIM, browser automation Playwright, dan menyimpan token OAuth ke database 9router.

```
python run.py
```

```
 ____  _    _ ____  ____   ____  _   _
| __ )| |  | |  _ \|  _ \ / ___|| \ | |
|  _ \| |  | | | | | | | | |    |  \| |
| |_) | |__| | |_| | |_| | |___ | |\  |
|____/ \____/|____/|____/ \____||_| \_|

CodeBuddy.cn Account Creator | MASANTOID
```

## Fitur

- **Headless browser** — Playwright jalan tanpa window
- **Rich UI** — Tampilan terminal profesional dengan panel, table, progress bar
- **Cross-platform** — Auto-detect path 9router di Windows, Linux, macOS
- **Batch processing** — Bikin banyak akun sekaligus dengan progress bar
- **Proxy checker** — Test koneksi proxy sebelum dipakai
- **Append token** — Data akun lama gak akan hilang

## Requirements

- Python 3.11+
- Playwright browser (Chromium)

```bash
pip install -r requirements.txt
playwright install chromium
```

## Quick Start

```bash
# Interactive menu
python run.py

# Cek saldo 5SIM
python run.py balance

# Test semua proxy
python run.py proxy

# Buat 1 akun
python run.py batch -c 1

# Batch 5 akun
python run.py batch -c 5

# Lihat token tersimpan
python run.py tokens

# Lihat konfigurasi
python run.py settings
```

## Konfigurasi

Semua konfigurasi ada di `config.toml`:

```toml
[5sim]
jwt = "..."              # 5SIM API key

[[proxies]]
label = "LOCAL"
type = "http"
host = "127.0.0.1"
port = 60000

[bot]
country = "hongkong"
service = "codebuddy"
```

## Rekomendasi Proxy

Untuk akses CodeBuddy.cn (geo-block China), rekomendasi proxy:

| Provider | Kelebihan | Harga |
|----------|-----------|-------|
| **[9Proxy](https://9proxy.com)** | Residential proxy China, dedicated IP, stabil | ~$3-5/bulan |
| **[Proxy-Seller](https://proxy-seller.com)** | ISP proxy China, dedicated | ~$2-4/bulan |
| **[SmartProxy](https://smartproxy.com)** | Residential rotating, pool China | ~$8/bulan |
| **VPS China** (Aliyun/Tencent) | Setup sendiri, paling stabil | ~$5-10/bulan |

> **Catatan:** CodeBuddy.cn API di-geoblock ke China. Proxy LOCAL (127.0.0.1:60000) mungkin gak bisa reach API. Untuk token polling (`copilot.tencent.com`), pastikan proxy bisa tembus ke endpoint tersebut. Kalau 9router di luar China, tambah proxy CN di config `providerSpecificData.connectionProxyUrl`.

## Struktur Project

```
budycn/
├── run.py                    # Entry point CLI
├── config.toml               # Konfigurasi
├── requirements.txt          # Dependencies
├── data/
│   └── oauth_tokens.json     # Token hasil
└── src/
    ├── cli/                  # Rich UI & menu
    ├── core/                 # Auth, browser, 5SIM, config
    ├── db/                   # 9router injection
    └── utils/                # Proxy checker
```

## License

Personal project — MASANTOID