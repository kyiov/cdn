"""Rich display helpers: panels, tables, progress bars."""
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeRemainingColumn
from rich.columns import Columns
from rich.align import Align
from rich import box

console = Console()


def print_banner():
    """Tampilkan banner header dalam panel box."""
    console.print()
    banner_text = (
        "[bold cyan]"
        " ____  _    _ ____  ____   ____  _   _\n"
        "| __ )| |  | |  _ \\|  _ \\ / ___|| \\ | |\n"
        "|  _ \\| |  | | | | | | | | |    |  \\| |\n"
        "| |_) | |__| | |_| | |_| | |___ | |\\  |\n"
        "|____/ \\____/|____/|____/ \\____||_| \\_|\n"
        "[/bold cyan]\n"
        "[bold white]CodeBuddy.cn Account Creator[/bold white]  [dim]|[/dim]  [yellow]MASANTOID[/yellow]"
    )

    console.print(Panel(
        Align.center(banner_text),
        border_style="cyan",
        box=box.DOUBLE,
        padding=(1, 2),
        title="[bold cyan]v1.0.0[/bold cyan]",
        title_align="right",
        subtitle="[dim]5SIM + Playwright Automation[/dim]",
        subtitle_align="center",
    ))
    console.print()


def print_balance(balance_data):
    """Tampilkan saldo 5SIM dalam panel."""
    bal = balance_data.get("balance", "N/A")
    email = balance_data.get("email", "N/A")
    acc_id = balance_data.get("id", "N/A")

    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column("Key", style="dim")
    table.add_column("Value", style="bold")
    table.add_row("Balance", f"[green]${bal}[/green]")
    table.add_row("Email", str(email))
    table.add_row("Account ID", str(acc_id))

    console.print(Panel(table, title="[bold]5SIM Account[/bold]", border_style="green"))
    console.print()


def print_price(price_data):
    """Tampilkan harga & stock."""
    if not price_data:
        console.print("[dim]  Price data not available[/dim]")
        return
    price = price_data.get("price", "N/A")
    stock = price_data.get("count", "N/A")
    console.print(f"  [dim]HK CodeBuddy:[/dim] [yellow]${price}[/yellow] | Stock: [cyan]{stock}[/cyan]")
    console.print()


def print_proxy_status(proxy_results):
    """Tampilkan hasil proxy check dalam table."""
    table = Table(title="Proxy Status", box=box.ROUNDED, border_style="blue")
    table.add_column("Label", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("IP", style="dim")
    table.add_column("Latency", justify="right")
    table.add_column("CN Reachable", style="bold")

    for r in proxy_results:
        status = "[green]✓ OK[/green]" if r["working"] else f"[red]✗ FAIL[/red]"
        ip = r.get("ip") or "-"
        latency = f"{r['latency_ms']}ms" if r.get("latency_ms") else "-"
        cn = "[green]Yes[/green]" if r.get("codebuddy_cn_reachable") else "[red]No[/red]"
        if r.get("error"):
            cn = f"[red]{r['error'][:40]}[/red]"
        table.add_row(r["label"], status, ip, latency, cn)

    console.print(table)
    console.print()


def print_account_summary(accounts):
    """Tampilkan summary hasil batch creation."""
    table = Table(title="Batch Summary", box=box.ROUNDED, border_style="green")
    table.add_column("Phone", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Error", style="red")

    ok_count = sum(1 for a in accounts if a["status"] == "OK")
    fail_count = len(accounts) - ok_count

    for a in accounts:
        status_style = "[green]OK[/green]" if a["status"] == "OK" else "[red]FAIL[/red]"
        table.add_row(a.get("phone", "N/A"), status_style, a.get("error", "") or "")

    console.print(table)
    console.print(Panel(
        f"[green]{ok_count} OK[/green] | [red]{fail_count} FAIL[/red]",
        title="Result",
        border_style="green" if fail_count == 0 else "yellow",
    ))
    console.print()


def print_tokens(tokens):
    """Tampilkan daftar token tersimpan."""
    if not tokens:
        console.print("[dim]  No tokens saved yet.[/dim]")
        return

    table = Table(title="Saved Tokens", box=box.ROUNDED, border_style="cyan")
    table.add_column("#", style="dim")
    table.add_column("Phone", style="cyan")
    table.add_column("Access Token", style="dim", no_wrap=True, max_width=60)
    table.add_column("Expires In", justify="right")

    for i, t in enumerate(tokens, 1):
        at = t.get("accessToken", "")[:50] + "..."
        exp = t.get("expiresIn", "N/A")
        table.add_row(str(i), t.get("phone", "N/A"), at, str(exp))

    console.print(table)
    console.print(f"  [dim]Total: {len(tokens)} account(s)[/dim]")
    console.print()


def create_progress():
    """Buat Rich Progress context untuk batch processing."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("({task.completed}/{task.total})"),
        TimeRemainingColumn(),
        console=console,
    )


def print_success(message):
    """Tampilkan pesan sukses."""
    console.print(f"  [green]✓[/green] {message}")


def print_error(message):
    """Tampilkan pesan error."""
    console.print(f"  [red]✗[/red] {message}")


def print_info(message):
    """Tampilkan pesan info."""
    console.print(f"  [dim]→[/dim] {message}")


def print_settings(settings):
    """Tampilkan konfigurasi saat ini."""
    table = Table(title="Settings", box=box.ROUNDED, border_style="blue")
    table.add_column("Key", style="dim")
    table.add_column("Value", style="bold")

    for k, v in settings.items():
        if isinstance(v, dict):
            for sk, sv in v.items():
                table.add_row(f"{k}.{sk}", str(sv))
        elif isinstance(v, list):
            table.add_row(k, f"{len(v)} items")
        else:
            table.add_row(k, str(v))

    console.print(table)
    console.print()


def print_menu(menu_items):
    """Tampilkan menu dalam Rich Panel box."""
    menu_text = ""
    for key, (label, _) in menu_items.items():
        icon = _icon_for(key)
        menu_text += f"  [{icon}] [[cyan bold]{key}[/cyan bold]] [bold white]{label}[/bold white]\n"

    panel = Panel(
        menu_text.rstrip(),
        title="[bold cyan]MAIN MENU[/bold cyan]",
        subtitle="[dim]-- Select option --[/dim]",
        border_style="cyan",
        box=box.SQUARE,
        padding=(1, 2),
    )
    console.print(panel)
    console.print()


def _icon_for(key):
    """Return icon untuk setiap menu item."""
    icons = {
        "1": "[bold green]$[/bold green]",
        "2": "[bold yellow]~[/bold yellow]",
        "3": "[bold cyan]+[/bold cyan]",
        "4": "[bold magenta]*[/bold magenta]",
        "5": "[bold blue]#[/bold blue]",
        "6": "[dim]~[/dim]",
        "7": "[red]x[/red]",
    }
    return icons.get(key, ">")