#!/usr/bin/env python3
"""Inject BAI API keys into the 9router SQLite DB (providerConnections table).

9router stores each upstream as a row in `providerConnections` with a
`data` JSON blob. We mirror the exact shape of the existing
openai-compatible-chat-<uuid> rows so the gateway picks them up.

Safe: backs up the DB before any write, dedupes on apiKey, idempotent.
"""
import json, shutil, sqlite3, uuid, datetime, os, sys

# Rich TUI kit — semua print lewat ui.say biar masuk card aktif (kalau ada)
import importlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ui = importlib.import_module("ui")
say = ui.say

BACKUP_SUFFIX = ".bak"


def iso_now():
    return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'


def read_keys(path):
    """Return list of {email, key} from api_keys.json (or plain keys)."""
    with open(path) as f:
        data = json.load(f)
    out = []
    for item in data:
        if isinstance(item, dict):
            out.append({"email": item.get("email", ""), "key": item.get("key", "")})
        else:
            out.append({"email": "", "key": item})
    return [x for x in out if x["key"]]


def backup(db_path):
    dst = db_path + BACKUP_SUFFIX
    try:
        shutil.copy2(db_path, dst)
        return dst
    except Exception as e:
        say(f"[warn] backup failed: {e}", color="warn")
        return None


def existing_keys(cur):
    keys = set()
    try:
        for (d, ) in cur.execute("SELECT data FROM providerConnections"):
            try:
                keys.add(json.loads(d).get("apiKey", ""))
            except Exception:
                pass
    except Exception:
        pass
    return keys


def detect_db_path():
    """Return the 9router DB path for this OS: first existing candidate, else the
    OS default (inject() then reports 'db not found' gracefully)."""
    home = os.path.expanduser("~")
    if os.name == "nt":
        candidates = [
            os.path.join(os.environ.get("USERPROFILE", home), ".9router", "db", "data.sqlite"),
            os.path.join(os.environ.get("APPDATA", ""), "9router", "db", "data.sqlite"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "9router", "db", "data.sqlite"),
        ]
    elif sys.platform == "darwin":
        candidates = [
            os.path.join(home, ".9router", "db", "data.sqlite"),
            os.path.join(home, "Library", "Application Support", "9router", "db", "data.sqlite"),
        ]
    else:
        xdg = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
        candidates = [
            os.path.join(home, ".9router", "db", "data.sqlite"),
            os.path.join(xdg, "9router", "db", "data.sqlite"),
        ]
    candidates = [c for c in candidates if c]
    for c in candidates:
        if os.path.exists(c):
            return c
    return candidates[0]


def resolve_db_paths(inject_cfg):
    """Normalize the [inject] config into a list of DB paths.

    Accepts `db_paths` (string or list), legacy `db_path` (string), or nothing
    (auto-detect). Expands ~ and env vars, dedupes preserving order. Missing
    explicit paths are kept — the per-path failure shows at inject time.
    """
    v = inject_cfg.get("db_paths") or inject_cfg.get("db_path")
    if isinstance(v, str):
        paths = [v]
    elif isinstance(v, (list, tuple)):
        paths = list(v)
    else:
        paths = [detect_db_path()]
    paths = [os.path.expandvars(os.path.expanduser(str(p))) for p in paths if p]
    return list(dict.fromkeys(paths)) or [detect_db_path()]


def _find_9router_cli_js():
    """Locate 9router's cli.js for this OS. Returns None if not found."""
    home = os.path.expanduser("~")
    if os.name == "nt":
        candidates = [
            os.path.join(os.environ.get("APPDATA", ""), "npm", "node_modules", "9router", "cli.js"),
            os.path.join(os.environ.get("ProgramFiles", ""), "nodejs", "node_modules", "9router", "cli.js"),
        ]
    elif sys.platform == "darwin":
        candidates = [
            "/opt/homebrew/lib/node_modules/9router/cli.js",
            "/usr/local/lib/node_modules/9router/cli.js",
        ]
    else:
        candidates = [
            "/usr/lib/node_modules/9router/cli.js",
            "/usr/local/lib/node_modules/9router/cli.js",
            os.path.join(home, ".npm-global", "lib", "node_modules", "9router", "cli.js"),
        ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def restart_9router(cli_path=None, cli_js=None):
    """Restart the 9router gateway (kill node+next-server, relaunch --tray).
    Only call when the user opts in — it drops in-flight requests.
    Windows: auto-restart not supported; prints a manual-restart hint."""
    import subprocess, signal, time, os
    if os.name == "nt":
        say("[windows] auto-restart tidak didukung — restart 9router manual", color="warn")
        return False
    cli_path = cli_path or shutil.which("node") or "/usr/bin/node"
    cli_js = cli_js or _find_9router_cli_js()
    if not cli_js:
        say("9router cli.js not found; restart manual", color="warn")
        return False
    # find current PIDs
    out = subprocess.run(["pgrep", "-f", "9router/cli.js"], capture_output=True, text=True).stdout.split()
    children = subprocess.run(["pgrep", "-f", "next-server"], capture_output=True, text=True).stdout.split()
    pids = out + [p for p in children if p not in out]
    if not pids:
        say("9router not running; nothing to restart", color="dim")
        return False
    for p in pids:
        try:
            os.kill(int(p), signal.SIGTERM)
        except Exception:
            pass
    time.sleep(3)
    # relaunch
    try:
        subprocess.Popen([cli_path, cli_js, "--tray", "--skip-update"],
                         stdout=open(os.devnull, "w"), stderr=open(os.devnull, "w"),
                         start_new_session=True)
        say("restarted 9router (--tray)", color="ok")
        return True
    except Exception as e:
        say(f"relaunch failed: {e}", color="err")
        return False


def inject(keys, db_path, default_model="glm-5.3-flash", base_url="https://api.b.ai/v1",
           prefix="bai", numbered=True, priority=1, name=None, auto_restart=False):
    """Insert one providerConnections row per key. Returns list of (email, status).
    If auto_restart is True, restarts the gateway after insert so it picks up the new rows.

    ######## IMPORTANT — 9router schema ########
    9router needs BOTH tables to route a custom OpenAI-compatible provider:
      - providerNodes:      ONE row defining the NODE  (id=type-<uuid>, type, name,
                            data={prefix, apiType, baseUrl}).
      - providerConnections: rows holding each KEY, whose `provider` column MUST equal
                            the providerNodes.id (so multiple keys share one node).
    Injecting only into providerConnections (with a fresh uuid per key) leaves NO
    node -> gateway says "No active credentials for provider:<prefix>".
    This function now creates the node (if missing) and links all keys to it.
    """
    if not os.path.exists(db_path):
        return [(k["email"], f"db not found: {db_path}") for k in keys]

    backup(db_path)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # ---- ensure the node exists ----
    node = cur.execute("SELECT id FROM providerNodes WHERE name=?", (prefix,)).fetchone()
    if node:
        node_id = node[0]
        say(f"reuse node '{prefix}' id={node_id[:30]}...", color="info")
    else:
        node_id = f"openai-compatible-chat-{uuid.uuid4()}"
        now = iso_now()
        node_data = {"prefix": prefix, "apiType": "chat", "baseUrl": base_url}
        cur.execute(
            "INSERT INTO providerNodes (id,type,name,data,createdAt,updatedAt) VALUES (?,?,?,?,?,?)",
            (node_id, "openai-compatible", prefix, json.dumps(node_data), now, now))
        say(f"created node '{prefix}' id={node_id[:30]}...", color="info")

    existing = existing_keys(cur)

    results = []
    inserted = 0
    skipped = 0
    # Continue numbering from rows already attached to this node, so per-key
    # injects (1 key per call) don't all land on `bai-1`.
    n = cur.execute("SELECT COUNT(*) FROM providerConnections WHERE provider=?",
                    (node_id,)).fetchone()[0] if numbered else 0
    for k in keys:
        n += 1
        ak = k["key"]
        if not ak:
            results.append((k["email"], "no key"))
            continue
        if ak in existing:
            results.append((k["email"], "already injected"))
            skipped += 1
            continue

        # provider = the SAME node id (NOT a fresh uuid per key)
        provider = node_id
        now = iso_now()

        # label: bai-<n> (numbered) or bai-<email>, or explicit name
        if name:
            label = name
        elif numbered:
            label = f"{prefix}-{n}"
        else:
            label = f"{prefix}-{k['email'].split('@')[0]}"

        data = {
            "defaultModel": default_model,
            "apiKey": ak,
            # IMPORTANT: 9router marks a connection unavailable (red/hidden) if
            # its connection test fails. B.AI keys 403 on PREMIUM models but GLM
            # works free — so we set testStatus:active + backoffLevel:0 so the
            # provider shows green in the UI and is actually routed. This is the
            # documented healthy-default pattern for B.AI (see 9router-add-provider).
            "testStatus": "active",
            "backoffLevel": 0,
            "providerSpecificData": {
                "prefix": prefix,
                "apiType": "chat",
                "baseUrl": base_url,
                "nodeName": prefix,
                "connectionProxyEnabled": False,
                "connectionProxyUrl": "",
                "connectionNoProxy": "",
            },
        }
        cur.execute(
            "INSERT INTO providerConnections "
            "(id, provider, authType, name, email, priority, isActive, data, createdAt, updatedAt) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), provider, "apikey", label, k["email"], priority, 1,
             json.dumps(data), now, now))
        existing.add(ak)
        inserted += 1
        results.append((k["email"], f"injected as {label}"))
        say(f"+ {label:<18} {ak[:10]}...", color="ok")

    conn.commit()
    conn.close()
    say(f"injected {inserted}, skipped {skipped}")

    if auto_restart and inserted:
        restart_9router()
    return results


def inject_to_devices(keys, db_paths, auto_restart=False, **inject_kwargs):
    """Run inject() against each DB; restart the gateway ONCE at the end if
    anything was inserted (avoids killing it N times for N paths)."""
    results = []
    any_injected = False
    for db in db_paths:
        say(f"=== 9router DB: {db} ===", color="hdr")
        res = inject(keys, db, auto_restart=False, **inject_kwargs)
        any_injected |= any(s.startswith("injected") for (_, s) in res)
        results += [{"email": e, "db": db, "status": s} for (e, s) in res]
    if auto_restart and any_injected:
        restart_9router()
    return results


def list_bai_providers(db_path, prefix="bai"):
    """Show which rows have nodeName = prefix (i.e. ours)."""
    if not os.path.exists(db_path):
        return []
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    out = []
    for (id_, provider, name, data,) in cur.execute(
            "SELECT id,provider,name,data FROM providerConnections"):
        try:
            d = json.loads(data)
        except Exception:
            continue
        if (d.get("providerSpecificData", {}).get("nodeName") == prefix):
            out.append({"id": id_, "provider": provider, "name": name,
                        "email": "", "model": d.get("defaultModel"),
                        "key": d.get("apiKey", "")[:10] + "..."})
    conn.close()
    return out


if __name__ == "__main__":
    # pretty small test wrapper; not the CLI
    say("use from bai_cli.py", color="dim")
