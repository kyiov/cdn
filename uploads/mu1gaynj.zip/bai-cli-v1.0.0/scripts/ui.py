#!/usr/bin/env python3
"""Rich TUI kit untuk BAI CLI — banner, cardbox per akun, tabel ringkasan, sound.

Semua output lewat module ini biar konsisten:
  - kalau `rich` ada DAN stdout TTY: pakai Panel/Live/Table (kartu rapi + animasi)
  - kalau di-pipe / rich gak ada: fallback plain-text otomatis (log tetap jalan)

Sound: WAV kecil digenerate di /tmp sekali pakai (ok/fail/done/start), diputar
async biar gak blocking. Matiin lewat [ui] sound=false di config.toml atau
env BAI_SOUND=0 / BAI_PLAIN=1.

Layout batch:
  banner (Panel)  →  Live: satu Panel "card" per akun berjalan (spinner + log +
  progress bar)  →  tabel ringkasan akhir + sound.

Cara pakai dari modul lain:

    import importlib, os, sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    ui = importlib.import_module("ui")

    ui.banner_panel(title="BAI BATCH", stats=ui.stats_line(akun=10, proxy=5), start=True)
    card = ui.set_account(email, total=10, idx=1)
    card.say("login ok", color="ok")          # tiap say() otomatis masuk card
    ui.active_card().progress(1, 4)           # update progress bar
    ui.end_card()                             # tutup card
    ui.result_table(rows, title="HASIL")
    ui.done_sound()
"""
import math
import os
import re
import struct
import subprocess
import sys
import time
import wave

from shutil import which

__all__ = [
    "say", "banner", "banner_panel", "menu_panel", "stats_line",
    "result_table", "provider_table", "summary_table", "table",
    "set_account", "active_card", "end_card", "account_card",
    "fmt", "ok_sound", "fail_sound", "done_sound", "start_sound",
    "sound_enabled", "rich_ok", "animate_enabled",
]

# ────────────────────────────── rich import ──────────────────────────────
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.live import Live
    from rich.table import Table
    from rich.text import Text
    from rich.align import Align
    from rich.theme import Theme
    from rich import box
    RICH_MODULE = True
except Exception:
    RICH_MODULE = False

RICH_ENABLED = bool(RICH_MODULE) and sys.stdout.isatty()
rich_ok = RICH_ENABLED

# ────────────────────────────── config / env ──────────────────────────────
def _cfg_ui():
    """Baca [ui] dari config.toml project (kalau ada) — tanpa wajib tomllib."""
    try:
        import tomllib
    except Exception:
        return {}
    base = os.environ.get("BAI_BASE") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = os.path.join(base, "config.toml")
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "rb") as f:
            return (tomllib.load(f) or {}).get("ui", {})
    except Exception:
        return {}

_CFG = _cfg_ui()

def _env_bool(env, default):
    v = os.environ.get(env)
    return default if v is None else v.strip().lower() not in ("0", "false", "no", "off", "")

PLAIN = os.environ.get("BAI_PLAIN", "0") not in ("0", "false", "no", "")
SOUND = _env_bool("BAI_SOUND", _CFG.get("sound", True))
ANIMATE = _env_bool("BAI_ANIMATE", _CFG.get("animate", True))
RICH_FORCE = _env_bool("BAI_RICH_FORCE", _CFG.get("force", False))
# rich aktif kalau: module ada DAN (TTY ATAU dipaksa) DAN gak plain
RICH_ENABLED = bool(RICH_MODULE) and (sys.stdout.isatty() or RICH_FORCE) and not PLAIN
rich_ok = RICH_ENABLED
sound_enabled = bool(SOUND)
animate_enabled = bool(ANIMATE) and RICH_ENABLED

# ────────────────────────────── palette / theme ──────────────────────────────
CY = "bright_cyan"; BL = "bright_blue"; GR = "bright_green"; YW = "bright_yellow"
RD = "bright_red"; PU = "bright_magenta"; GY = "bright_black"; OR = "yellow"
WT = "white"; PK = "magenta"; BG = "grey11"

_theme = Theme({
    "ok": "bold bright_green", "err": "bold bright_red", "warn": "bright_yellow",
    "info": "bright_cyan", "dim": "bright_black", "hdr": "bold bright_cyan",
    "key": "bright_magenta", "em": "bold white",
})

def _console(**kw):
    return Console(theme=_theme, **kw)

CONSOLE = _console() if RICH_MODULE else None

# ────────────────────────────── plain fallback ──────────────────────────────
_ANSI = {
    "red": "\033[38;5;203m", "green": "\033[38;5;48m", "yellow": "\033[38;5;220m",
    "blue": "\033[38;5;33m", "cyan": "\033[38;5;51m", "magenta": "\033[38;5;135m",
    "gray": "\033[38;5;243m", "white": "\033[38;5;255m", "reset": "\033[0m",
    "bold": "\033[1m", "dim": "\033[2m",
}

_PLAIN_COLOR = {
    "ok": "green", "err": "red", "warn": "yellow", "info": "cyan",
    "dim": "gray", "hdr": "cyan", "key": "magenta", "em": "white",
    "red": "red", "green": "green", "yellow": "yellow", "blue": "blue",
    "cyan": "cyan", "magenta": "magenta", "white": "white",
    "bright_green": "green", "bright_red": "red", "bright_yellow": "yellow",
    "bright_cyan": "cyan", "bright_blue": "blue", "bright_magenta": "magenta",
    "bright_black": "gray",
}

def _plain(text, color=None, bold=False, dim=False):
    if not sys.stdout.isatty():        # piped → strip warna total
        return text
    c = _PLAIN_COLOR.get(color)
    pre = (_ANSI.get(c, "") + _ANSI["bold"]) if (c and bold) else (
          _ANSI.get(c, "") if c else (_ANSI["dim"] if dim else ""))
    return f"{pre}{text}{_ANSI['reset']}" if pre else text

def _markup(text, color=None, bold=False):
    """Bungkus teks dengan tag rich — hati-hati: tag penutup hanya kalau bold."""
    if bold and color:
        return f"[bold {color}]{text}[/bold {color}]"
    if bold:
        return f"[bold]{text}[/bold]"
    if color:
        return f"[{color}]{text}[/{color}]"
    return text

def fmt(text, color=None, bold=False):
    """Warna/format satu string — Rich kalau aktif, ANSI plain kalau TTY,
    polos kalau pipe."""
    if RICH_ENABLED:
        return _markup(text, color, bold)
    return _plain(text, color, bold)

def say(text="", color=None, bold=False):
    """Tulis satu baris — kalau ada card aktif (mode batch), masuk ke card."""
    if RICH_ENABLED and _LIVE.card is not None:
        _LIVE.card.say(text, color, bold)
        _LIVE.refresh()
        return
    if RICH_ENABLED:
        CONSOLE.print(_markup(text, color, bold))
    elif sys.stdout.isatty():
        print(_plain(text, color, bold))
    else:
        print(text)

# ────────────────────────────── sound (WAV async) ──────────────────────────────
# (path, freq, durasi, decay) — decay=0 → beep datar
_SOUNDS = {
    "ok":    ("/tmp/bai_ok.wav",    880, 0.09, 0.10),
    "fail":  ("/tmp/bai_fail.wav",  196, 0.28, 0.30),
    "done":  ("/tmp/bai_done.wav",  523, 0.10, 0.06),
    "start": ("/tmp/bai_start.wav", 440, 0.05, 0.05),
}
_PLAYER = None   # None = belum dicek

def _find_player():
    """Cari pemutar suara CLI pertama yang ada. Hasilnya di-cache."""
    global _PLAYER
    if _PLAYER is not None:
        return _PLAYER
    if sys.platform == "darwin":
        _PLAYER = "afplay"
    elif which("pw-play"):
        _PLAYER = "pw-play"
    elif which("paplay"):
        _PLAYER = "paplay"
    elif which("aplay"):
        _PLAYER = "aplay"
    elif which("ffplay"):
        _PLAYER = "ffplay"
    else:
        _PLAYER = False            # gak ada player → senyap (bukan error)
    return _PLAYER

def _ensure_wav(name):
    """Generate WAV kecil sekali di /tmp (~3-4 KB) — dipakai ulang."""
    path, freq, dur, decay = _SOUNDS[name]
    if os.path.exists(path) and os.path.getsize(path) > 100:
        return path
    try:
        rate = 22050
        n = int(rate * dur)
        pcm = bytearray()
        two_pi = 6.283185307179586
        for i in range(n):
            t = i / rate
            amp = max(0.05, 1.0 - t / decay) if decay else 1.0
            # fundamental + overtone biar gak kedengaran "beep komputer" mentah
            v = int(amp * 12000 * (0.55 * math.sin(two_pi * freq * t)
                                   + 0.45 * math.sin(two_pi * freq * 2 * t)))
            pcm += struct.pack("<h", max(-32768, min(32767, v)))
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(bytes(pcm))
        return path
    except Exception:
        return None

def _player_cmd(path):
    return {
        "afplay":  ["afplay", path],
        "pw-play": ["pw-play", "--volume=0.7", path],
        "paplay":  ["paplay", "--volume=45000", path],
        "aplay":   ["aplay", "-q", path],
        "ffplay":  ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path],
    }[_PLAYER]

def _play(path):
    try:
        subprocess.Popen(_player_cmd(path),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def _beep(name, count=1):
    if not SOUND:
        return
    try:
        player = _find_player()
        if not player:
            return
        path = _ensure_wav(name)
        if not path:
            return
        for _ in range(count):
            _play(path)
    except Exception:
        pass

def ok_sound(count=1):
    """Beep sukses (asinkron)."""
    _beep("ok", count)

def fail_sound(count=1):
    """Beep gagal (asinkron)."""
    _beep("fail", count)

def done_sound(count=1):
    """Beep akhir batch (asinkron)."""
    _beep("done", count)

def start_sound(count=1):
    """Beep mulai batch (asinkron)."""
    _beep("start", count)

# ────────────────────────────── banner ──────────────────────────────
_GRAD_A = (33, 135, 255)     # biru
_GRAD_B = (196, 120, 255)    # ungu-soft

def _grad_text(title, phase=0.0):
    """Judul dengan gradient per karakter (biru → ungu). phase 0..1 geser
    gradiennya biar bisa di-animasi (shimmer)."""
    t = Text("", style="bold")
    n = max(1, len(title) - 1)
    for i, ch in enumerate(title):
        k = (i / n + phase) % 1.0
        r = int(_GRAD_A[0] + (_GRAD_B[0] - _GRAD_A[0]) * k)
        g = int(_GRAD_A[1] + (_GRAD_B[1] - _GRAD_A[1]) * k)
        b = int(_GRAD_A[2] + (_GRAD_B[2] - _GRAD_A[2]) * k)
        t.append(ch, style=f"bold rgb({r},{g},{b})")
    return t

def _panel_body(title, tag="", sub=None, stats=None, phase=0.0):
    body = Text()
    body.append(_grad_text(title, phase))
    if tag:
        body.append("\n")
        body.append(tag, style="dim")
    if sub:
        body.append("\n")
        body.append(sub)
    if stats:
        body.append("\n")
        body.append(Text.from_markup(stats))     # parse markup [em]/[key] di stats_line
    return body

def banner():
    """Banner utama — Panel rich kalau TTY, blok polos kalau pipe.
    Animasi shimmer pada judul (gradien jalan 3×) kalau animate on."""
    title = "BAI · CLI"
    tag = "auto register · claim · key · inject"
    sub = Text()
    sub.append("chat.b.ai", style="info")
    sub.append("   +   ", style="dim")
    sub.append("9router gateway", style="warn")
    if not RICH_ENABLED:
        print(f"\n{'─' * 56}\n  {title}\n  {tag}\n  chat.b.ai  +  9router gateway\n{'─' * 56}\n")
        return
    panel = Panel(Align.center(_panel_body(title, tag, sub)),
                  border_style="cyan", box=box.ROUNDED, padding=(1, 4),
                  subtitle="[dim]modern cardbox edition[/dim]")
    if not animate_enabled:
        CONSOLE.print(panel)
        return
    with Live(panel, console=CONSOLE, auto_refresh=False, screen=False,
              transient=True) as live:
        n = 12
        for f in range(1, n + 1):
            live.update(Panel(
                Align.center(_panel_body(title, tag, sub, phase=(f / n) * 3)),
                border_style="cyan", box=box.ROUNDED, padding=(1, 4),
                subtitle="[dim]modern cardbox edition[/dim]"), refresh=True)
            time.sleep(0.04)
    CONSOLE.print(panel)

def banner_panel(*, title="BAI · CLI", tag="auto register · claim · key · inject",
                 stats=None, start=True):
    """Banner panel buat mode batch (title + statistik + play sound kalau start)."""
    if start:
        start_sound()
    if not RICH_ENABLED:
        print(f"\n{'─' * 56}\n  {title}\n  {tag}"
              + (f"\n  {stats}" if stats else "") + f"\n{'─' * 56}\n")
        return
    body = _panel_body(title, tag, stats=stats)
    panel = Panel(Align.center(body), border_style="cyan", box=box.ROUNDED,
                  padding=(1, 4), subtitle="[dim]modern cardbox edition[/dim]")
    if not animate_enabled:
        CONSOLE.print(panel)
        return
    with Live(panel, console=CONSOLE, auto_refresh=False, screen=False,
              transient=True) as live:
        n = 10
        for f in range(1, n + 1):
            live.update(Panel(
                Align.center(_panel_body(title, tag, stats=stats, phase=(f / n) * 2)),
                border_style="cyan", box=box.ROUNDED, padding=(1, 4),
                subtitle="[dim]modern cardbox edition[/dim]"), refresh=True)
            time.sleep(0.04)
    CONSOLE.print(panel)

def stats_line(**kw):
    """Baris statistik kecil utk banner (akun/proxy/invite/inject)."""
    parts = []
    if "akun" in kw:
        parts.append(f"● akun [em]{kw['akun']}[/em]")
    if "proxy" in kw:
        parts.append(f"● proxy [em]{kw['proxy']}[/em]")
    if "invite" in kw:
        parts.append(f"● invite [key]{kw['invite']}[/key]")
    if "inject" in kw:
        parts.append(f"● inject [em]{'ON' if kw['inject'] else 'OFF'}[/em]")
    return "   ".join(parts)

def menu_panel(items):
    """Menu utama sebagai Panel + tabel pilihan. items = (num, label) tuples.
    Animasi: item muncul bertahap dari atas (stagger reveal) kalau animate on."""
    if not RICH_ENABLED:
        for num, label in items:
            print(f"  [{num}] {label}")
        print(f"  [q] Keluar")
        return
    all_rows = [(f"[bold]{n}[/bold]", "▸", f"[em]{l}[/em]") for n, l in items]
    all_rows.append(("[bold red]q[/bold red]", "✕", "[bold]Keluar[/bold]"))
    if not animate_enabled:
        grid = Table.grid(padding=(0, 1))
        grid.add_column(style="cyan", width=5, justify="right")
        grid.add_column(width=1)
        grid.add_column(justify="left")
        for r in all_rows:
            grid.add_row(*r)
        CONSOLE.print(Panel(grid, title="[bold cyan]PILIH AKSI[/bold cyan]",
                            border_style="cyan", box=box.ROUNDED, padding=(1, 2)))
        return
    with Live("", console=CONSOLE, auto_refresh=False, screen=False,
              transient=True) as live:
        for k in range(1, len(all_rows) + 1):
            grid = Table.grid(padding=(0, 1))
            grid.add_column(style="cyan", width=5, justify="right")
            grid.add_column(width=1)
            grid.add_column(justify="left")
            for r in all_rows[:k]:
                grid.add_row(*r)
            live.update(Panel(grid, title="[bold cyan]PILIH AKSI[/bold cyan]",
                              border_style="cyan", box=box.ROUNDED, padding=(1, 2)),
                        refresh=True)
            time.sleep(0.05)
    grid = Table.grid(padding=(0, 1))
    grid.add_column(style="cyan", width=5, justify="right")
    grid.add_column(width=1)
    grid.add_column(justify="left")
    for r in all_rows:
        grid.add_row(*r)
    CONSOLE.print(Panel(grid, title="[bold cyan]PILIH AKSI[/bold cyan]",
                        border_style="cyan", box=box.ROUNDED, padding=(1, 2)))

# ────────────────────────────── tabel ──────────────────────────────
def table(title=None, cols=(), rows=()):
    """Tabel generik — dibungkus Panel (semua dalam box). cols = (nama, style,
    justify), rows = tuple per baris. Plain mode → baris teks sederhana."""
    if not RICH_ENABLED:
        if title:
            print(f"\n{title}")
        for r in rows:
            print("  " + "  ".join(str(c) for c in r))
        return
    t = Table(title=None, border_style="bright_black", box=box.SIMPLE_HEAVY,
              padding=(0, 1))
    for name, style, justify in cols:
        t.add_column(name, style=style, justify=justify)
    for r in rows:
        t.add_row(*[str(c) for c in r])
    CONSOLE.print(Panel(t, title=title if title else None,
                        title_align="center",
                        border_style="cyan" if title else "bright_black",
                        box=box.ROUNDED, padding=(0, 2)))

def result_table(rows, title=None):
    """Tabel hasil batch per akun: # | email | status | waktu."""
    table(title=title,
          cols=(("#", "dim", "right"), ("Email", "white", "left"),
                ("Status", "", "left"), ("Waktu", "dim", "right")),
          rows=rows)

def provider_table(rows, title=None):
    """Tabel provider 9router: name | model | key."""
    table(title=title,
          cols=(("Provider", "bright_green", "left"),
                ("Model", "dim", "left"), ("Key", "dim", "left")),
          rows=rows)

def summary_table(stats, title=None):
    """Tabel ringkasan batch: total / ok / fail / key. Angka count-up (animasi)
    kalau animate on."""
    pairs = [("Total akun", str(stats.get("total", 0))),
             ("Sukses", str(stats.get("ok", 0))),
             ("Gagal", str(stats.get("fail", 0))),
             ("Sudah claim", str(stats.get("claimed", 0))),
             ("Key dibuat", str(stats.get("keys", 0)))]
    if not animate_enabled:
        table(title=title, cols=(("", "dim", "left"), ("", "white", "right")),
              rows=pairs)
        return
    targets = [int(p[1]) for p in pairs]
    steps = max(1, min(15, max(targets) or 1))
    with Live("", console=CONSOLE, auto_refresh=False, screen=False,
              transient=True) as live:
        for s in range(1, steps + 1):
            shown = [(name, str(int(t * s / steps)))
                     for name, t in zip((p[0] for p in pairs), targets)]
            t = Table(border_style="bright_black", box=box.SIMPLE_HEAVY, padding=(0, 1))
            t.add_column(style="dim", justify="left")
            t.add_column(style="white", justify="right")
            for name, val in shown:
                t.add_row(name, val)
            live.update(Panel(t, title=title if title else None, title_align="center",
                              border_style="cyan", box=box.ROUNDED, padding=(0, 2)),
                        refresh=True)
            time.sleep(0.05)
    table(title=title, cols=(("", "dim", "left"), ("", "white", "right")),
          rows=pairs)

# ────────────────────────────── cardbox per akun ──────────────────────────────
_SPINNER = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

class account_card:
    """Card per akun — ditampilkan di dalam Live (mode batch). Semua `say()`
    selama akun ini aktif nge-redirect ke card ini.

    say(text, color, bold) → tambah baris log ke card
    progress(done, n)      → update progress bar
    set_status(state)      → pending / ok / fail (ubah border + ikon judul)
    """

    def __init__(self, email, total=None, idx=None, rich_mode=True):
        self.email = email
        self.idx = idx
        self.total = total
        self._rich = rich_mode
        self.lines = []
        self.state = "pending"          # pending / ok / fail
        self._progress = None

    # ---------------- render (rich only) ----------------
    @property
    def markup(self):
        body = self._render_body()
        borders = {"pending": "cyan", "ok": "bright_green", "fail": "bright_red"}
        icons = {"pending": "⋯", "ok": "✓", "fail": "✕"}
        state = self.state
        style = borders.get(state, "cyan")
        num = f"{self.idx}/{self.total}" if (self.idx and self.total) else ""
        title = f"[bold {style}]{icons.get(state, '⋯')}[/bold {style}] {self.email} [dim]{num}[/dim]"
        return Panel(body or "[dim](menunggu log…)[/dim]", title=title,
                     border_style=style, box=box.ROUNDED, padding=(0, 1))

    def _progressbar(self):
        if self._progress is None:
            return ""
        done, n = self._progress
        w = 24
        filled = int(w * done / max(1, n))
        pct = int(100 * done / max(1, n))
        if not animate_enabled:
            return f"[dim]{'█' * filled}{'░' * (w - filled)}[/dim] [bold]{pct}%[/bold] ({done}/{n})"
        if done >= n:
            bar = "[ok]" + "█" * w + "[/ok]"
        else:
            wave = int(time.time() * 3) % 3
            chunk = ["▓", "▒", "░"][wave]
            if filled > 0:
                bar = f"[info]{'█' * (filled - 1)}{chunk}[/info]" + f"[dim]{'░' * (w - filled)}[/dim]"
            else:
                bar = f"[dim]{'░' * w}[/dim]"
        return f"{bar} [bold]{pct}%[/bold] ({done}/{n})"

    def _render_body(self):
        parts = []
        if self.state == "pending":
            parts.append(f"[cyan]{_SPINNER[int(time.time() * 8) % len(_SPINNER)]}[/cyan]")
        if self._progress is not None:
            parts.append(self._progressbar())
        if self.lines:
            parts.append("\n".join(self.lines[-12:]))
        return "\n".join(p for p in parts if p)

    # ---------------- interface utk modul lain ----------------
    def say(self, text="", color=None, bold=False):
        if not self._rich:
            print(_plain(text, color, bold))
            return
        style = f"{'bold ' if bold else ''}{color}" if color else ("bold" if bold else "")
        self.lines.append(f"[{style}]{text}[/{style}]" if style else text)

    def progress(self, done, n):
        if self._rich:
            self._progress = (done, n)

    def set_status(self, state):
        self.state = state


# ────────────────────────────── Live manager ──────────────────────────────
class _LiveMgr:
    """Holder Live + card aktif. Live restart per akun (card baru per akun)."""

    def __init__(self):
        self.live = None
        self.card = None

    def start(self, card):
        if self.live is None:
            self.live = Live(
                card.markup,
                console=CONSOLE,
                refresh_per_second=10,
                vertical_overflow="visible",
                auto_refresh=animate_enabled,   # spinner + wave jalan terus
            )
            self.live.start()
            self.live.refresh()
        self.card = card

    def refresh(self):
        if self.live is not None and self.card is not None:
            self.live.update(self.card.markup, refresh=True)

    def stop(self):
        if self.live is not None:
            self.live.stop()
            self.live = None
        self.card = None


_LIVE = _LiveMgr()


def set_account(email, total=None, idx=None):
    """Mulai card akun baru di dalam Live; `say()` global otomatis nulis ke card.
    Di mode plain, return card yang print langsung ke stdout."""
    end_card()
    card = account_card(email, total, idx, rich_mode=RICH_ENABLED)
    if RICH_ENABLED:
        _LIVE.start(card)
    else:
        _LIVE.card = card
    return card


def active_card():
    """Card akun yang sedang aktif (buat progress() dari fungsi dalam)."""
    return _LIVE.card


def end_card():
    """Tutup card akun aktif (Live berhenti)."""
    _LIVE.stop()
