#!/usr/bin/env python3
"""
BAI v8 - full register + claim, with total network recording.

Goals:
  1. register a fresh account via Google OAuth + invite code
  2. capture what the app really asks Turnstile for (hook render())
  3. solve via 2captcha and fire the REAL callback (not a hidden input)
  4. record every request/response incl. POST bodies -> see the true claim payload
  5. verify against /invite/my-registration before and after

Nothing is faked: if a step fails it is printed as failed.
"""
import asyncio, json, os, random, shutil, sys, time, urllib.request
from playwright.async_api import async_playwright

BASE      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EMAIL     = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("BAI_EMAIL", "contoh@example.com")
PASSWORD  = sys.argv[2] if len(sys.argv) > 2 else os.environ.get("BAI_PASSWORD", "")
INVITE    = "QC5MGL"
CAP_KEY   = os.environ.get("BAI_CAPKEY", "")   # isi lewat config/env
PAGE_URL  = "https://chat.b.ai/chat"
RUN       = "/tmp/bai_v8_run"
UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36")

USE_PROXY = "--no-proxy" not in sys.argv
PROXY = None
if USE_PROXY:
    with open(f"{BASE}/data/proxies_working.txt") as f:
        PROXY = random.choice([l.strip() for l in f if l.strip()])

NET_LOG = f"{BASE}/data/v8_network.jsonl"

# ---------------------------------------------------------------- turnstile hook
INIT_JS = r"""
(() => {
  window.__ts = {calls: [], log: []};
  const api = {
    render(container, params) {
      const id = 'ts_' + window.__ts.calls.length;
      window.__ts.calls.push({
        id: id,
        sitekey: params && params.sitekey,
        action: (params && params.action) || null,
        cData: (params && params.cData) || null,
        _cb: params && params.callback,
        _err: params && params['error-callback'],
        token: null,
      });
      window.__ts.log.push('render ' + id + ' sitekey=' + (params && params.sitekey));
      try {
        const el = typeof container === 'string'
          ? document.querySelector(container) : container;
        if (el && !el.querySelector('input[name="cf-turnstile-response"]')) {
          const i = document.createElement('input');
          i.type = 'hidden'; i.name = 'cf-turnstile-response';
          el.appendChild(i);
        }
      } catch (e) {}
      return id;
    },
    reset(id) { window.__ts.log.push('reset ' + id); },
    remove(id) { window.__ts.log.push('remove ' + id); },
    getResponse(id) {
      const c = window.__ts.calls.find(x => x.id === id) || window.__ts.calls[0];
      return (c && c.token) || '';
    },
    isExpired() { return false; },
    ready(cb) { try { cb(); } catch (e) {} },
    execute(container, params) {
      window.__ts.log.push('execute called');
      return api.render(container, params);
    },
  };
  Object.defineProperty(window, 'turnstile', {
    configurable: true,
    get() { return api; },
    set(v) { window.__ts.log.push('blocked overwrite of window.turnstile'); },
  });

  window.__tsFeed = (token, idx) => {
    const c = window.__ts.calls[idx || 0];
    if (!c) return 'no-widget-registered';
    c.token = token;
    document.querySelectorAll(
      'input[name="cf-turnstile-response"],textarea[name="cf-turnstile-response"]'
    ).forEach(el => {
      el.value = token;
      el.dispatchEvent(new Event('input', {bubbles: true}));
      el.dispatchEvent(new Event('change', {bubbles: true}));
    });
    if (typeof c._cb === 'function') {
      try { c._cb(token); return 'callback-fired'; }
      catch (e) { return 'callback-threw: ' + e; }
    }
    return 'no-callback-registered';
  };
})();
"""

# ---------------------------------------------------------------- 2captcha
def cap(path, payload):
    req = urllib.request.Request(
        f"https://api.2captcha.com/{path}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=40) as r:
        return json.loads(r.read().decode())


def solve_turnstile(sitekey, action=None, cdata=None):
    task = {"type": "TurnstileTaskProxyless",
            "websiteURL": PAGE_URL, "websiteKey": sitekey}
    if action:
        task["action"] = action
    if cdata:
        task["data"] = cdata
    r = cap("createTask", {"clientKey": CAP_KEY, "task": task})
    tid = r.get("taskId")
    print(f"    2captcha task={tid} action={action} cdata={cdata}")
    if not tid:
        print(f"    createTask failed: {r}")
        return None
    t0 = time.time()
    for _ in range(45):
        time.sleep(4)
        res = cap("getTaskResult", {"clientKey": CAP_KEY, "taskId": tid})
        if res.get("status") == "ready":
            tok = res["solution"]["token"]
            print(f"    SOLVED in {int(time.time()-t0)}s len={len(tok)}")
            return tok
        if res.get("errorId"):
            print(f"    2captcha error: {res}")
            return None
    print("    2captcha timeout")
    return None


# ---------------------------------------------------------------- helpers
async def click_text(page, texts, timeout=1500, label=""):
    for t in texts:
        try:
            b = page.locator(f"button:has-text('{t}')").first
            if await b.is_visible(timeout=timeout):
                await b.click()
                print(f"  >>> clicked {label}'{t}'")
                await page.wait_for_timeout(1500)
                return t
        except Exception:
            pass
    return None


async def google_login(page, ctx):
    print("\n[2] login flow")
    if not await click_text(page, ["Log in", "Sign in"], 8000):
        print("  no Log in button")
        return False
    await page.wait_for_timeout(1200)

    # invite code
    try:
        b = page.locator("button:has-text('Referral Code')").first
        if await b.is_visible(timeout=3000):
            await b.click()
            await page.wait_for_timeout(500)
            await page.fill("input[placeholder='Enter referral code']", INVITE)
            print(f"  >>> invite code {INVITE} entered")
            await page.wait_for_timeout(500)
    except Exception as e:
        print(f"  invite code field: {e}")

    print("  opening Google popup...")
    try:
        async with ctx.expect_page(timeout=20000) as pinfo:
            await page.click("button:has-text('Google')")
        g = await pinfo.value
    except Exception as e:
        print(f"  popup failed: {e}")
        return False

    await g.wait_for_load_state("domcontentloaded")
    await g.wait_for_timeout(3000)
    print(f"  popup url: {g.url[:90]}")

    if "identifier" in g.url.lower() or await g.locator("input#identifierId").count():
        await g.fill("input#identifierId", EMAIL, timeout=8000)
        await click_text(g, ["Next", "Berikutnya"], label="google ")
        await g.wait_for_timeout(4500)

    if any(k in g.url.lower() for k in ("challenge", "pwd")):
        await g.fill("input[name='Passwd']", PASSWORD, timeout=8000)
        await click_text(g, ["Next", "Berikutnya"], label="google ")
        await g.wait_for_timeout(5500)

    if any(k in g.url.lower() for k in ("speedbump", "termsofservice")):
        await click_text(g, ["I understand", "Saya mengerti", "Mengerti",
                             "Accept", "Setuju", "Continue", "Lanjutkan"],
                         label="speedbump ")
        await g.wait_for_timeout(5000)

    if any(k in g.url.lower() for k in ("consent", "oauth")):
        await g.wait_for_timeout(2000)
        await click_text(g, ["Continue", "Lanjutkan", "Allow", "Izinkan",
                             "Next", "Berikutnya"], label="consent ")
        try:
            await g.wait_for_timeout(8000)
        except Exception:
            print("  popup closed")

    print("  waiting for session...")
    for i in range(25):
        await page.wait_for_timeout(1000)
        ok = await page.evaluate("""() => {
            for (const b of document.querySelectorAll('button'))
                if (b.textContent.trim() === 'Log in' && b.offsetParent) return false;
            return true;
        }""")
        if ok:
            print(f"  LOGGED IN after {i+1}s")
            return True
        if i == 12:
            print("  reloading...")
            await page.reload(wait_until="domcontentloaded")
            await page.wait_for_timeout(4000)
    return False


CHECK_JS = r"""
async () => {
  const u = '/trpc/lambda/user.getUserState?input=' +
            encodeURIComponent(JSON.stringify({json:null, meta:{values:['undefined']}}));
  const r0 = await fetch(u, {credentials:'include'});
  const j0 = await r0.json();
  const d0 = j0?.result?.data?.json || {};
  const tok = d0.apiAccessToken;
  if (!tok) return {error: 'no apiAccessToken', status: r0.status};
  const r = await fetch('https://api.b.ai/api/activity/invite/my-registration',
                        {headers: {'X-Ainft-Auth-Token': 'Bearer ' + tok}});
  const body = await r.json();
  return {userId: d0.userId, email: d0.email, status: r.status, reg: body?.data};
}
"""


async def main():
    if os.path.exists(RUN):
        shutil.rmtree(RUN)
    os.makedirs(RUN, exist_ok=True)
    if os.path.exists(NET_LOG):
        os.remove(NET_LOG)

    print(f"email : {EMAIL}")
    print(f"invite: {INVITE}")
    print(f"proxy : {PROXY or 'DIRECT'}")

    netf = open(NET_LOG, "a")

    async with async_playwright() as p:
        kw = dict(
            headless=False,
            args=["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport={"width": 1280, "height": 900},
            user_agent=UA,
        )
        if PROXY:
            kw["proxy"] = {"server": PROXY}
        ctx = await p.chromium.launch_persistent_context(RUN, **kw)
        await ctx.add_init_script(INIT_JS)
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()

        INTEREST = ("invite", "claim", "reward", "bonus", "credit", "activity",
                    "turnstile", "getUserState", "auth/callback", "signup")

        async def on_request(req):
            if not any(k in req.url for k in INTEREST):
                return
            rec = {"t": "req", "method": req.method, "url": req.url[:300]}
            try:
                pd = req.post_data
                if pd:
                    rec["body"] = pd[:2000]
            except Exception:
                pass
            netf.write(json.dumps(rec) + "\n")
            netf.flush()
            if req.method == "POST":
                print(f"  [REQ] {req.method} {req.url[:110]}")
                if rec.get("body"):
                    print(f"        body: {rec['body'][:300]}")

        async def on_response(resp):
            if not any(k in resp.url for k in INTEREST):
                return
            body = ""
            try:
                body = await resp.text()
            except Exception:
                pass
            rec = {"t": "resp", "status": resp.status,
                   "url": resp.url[:300], "body": body[:2000]}
            netf.write(json.dumps(rec) + "\n")
            netf.flush()
            if "claim" in resp.url or "reward" in resp.url:
                print(f"  [RESP] {resp.status} {resp.url[:110]}")
                print(f"         {body[:400]}")

        page.on("request", lambda r: asyncio.create_task(on_request(r)))
        page.on("response", lambda r: asyncio.create_task(on_response(r)))

        print(f"\n[1] loading {PAGE_URL}")
        try:
            await page.goto(PAGE_URL, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            print(f"  goto failed: {e}")
        await page.wait_for_timeout(8000)

        # diagnose what actually loaded before assuming the button is missing
        diag = await page.evaluate("""() => ({
            url: location.href,
            title: document.title,
            bodyLen: (document.body?.innerText || '').length,
            head: (document.body?.innerText || '').slice(0, 400),
            buttons: Array.from(document.querySelectorAll('button'))
                       .filter(b => b.offsetParent)
                       .map(b => b.textContent.trim()).slice(0, 30),
        })""")
        print(f"  url    : {diag['url'][:100]}")
        print(f"  title  : {diag['title']}")
        print(f"  bodyLen: {diag['bodyLen']}")
        print(f"  buttons: {diag['buttons']}")
        if diag["bodyLen"] < 200:
            print(f"  body   : {diag['head']!r}")
        await page.screenshot(path=f"{BASE}/shots/v8_loaded.png", full_page=True)

        if not await google_login(page, ctx):
            print("\nLOGIN FAILED")
            await page.screenshot(path=f"{BASE}/shots/v8_loginfail.png", full_page=True)
            await ctx.close(); netf.close()
            return

        print("\n[3] post-login modals")
        await click_text(page, ["Got it", "Mengerti", "OK", "Start"], 6000)
        await page.wait_for_timeout(1500)

        before = await page.evaluate(CHECK_JS)
        print(f"\n[4] state BEFORE claim:\n{json.dumps(before, indent=2)[:900]}")

        claimed_btn = await click_text(
            page, ["Claim Free Credits", "Claim Credits", "Claim", "Klaim"], 8000)
        await page.wait_for_timeout(4000)

        print("\n[5] turnstile state")
        ts = await page.evaluate(
            "() => window.__ts ? {log: window.__ts.log, calls: window.__ts.calls.map("
            "c => ({id:c.id, sitekey:c.sitekey, action:c.action, cData:c.cData,"
            " hasCb: typeof c._cb === 'function'}))} : null")
        print(json.dumps(ts, indent=2)[:900])

        if ts and ts.get("calls"):
            c = ts["calls"][0]
            tok = solve_turnstile(c["sitekey"], c.get("action"), c.get("cData"))
            if tok:
                fed = await page.evaluate("([t,i]) => window.__tsFeed(t,i)", [tok, 0])
                print(f"    feed -> {fed}")
                await page.wait_for_timeout(4000)
                await click_text(page, ["Confirm", "Submit", "Verify", "Claim",
                                        "Continue", "OK"], 4000)
                await page.wait_for_timeout(6000)
        else:
            print("  no turnstile widget was rendered")
            btns = await page.evaluate(
                "() => Array.from(document.querySelectorAll('button'))"
                ".filter(b=>b.offsetParent).map(b=>b.textContent.trim()).slice(0,40)")
            print(f"  visible buttons: {btns}")

        await page.wait_for_timeout(3000)
        after = await page.evaluate(CHECK_JS)
        print(f"\n[6] state AFTER claim:\n{json.dumps(after, indent=2)[:900]}")

        rb = (before.get("reg") or {}) if isinstance(before, dict) else {}
        ra = (after.get("reg") or {}) if isinstance(after, dict) else {}
        print("\n===== VERDICT =====")
        for key in ("registration_reward", "signup_bonus"):
            print(f"{key}:")
            print(f"   before: {json.dumps(rb.get(key))}")
            print(f"   after : {json.dumps(ra.get(key))}")

        await page.screenshot(path=f"{BASE}/shots/v8_final.png", full_page=True)
        with open(f"{BASE}/data/v8_result.json", "w") as f:
            json.dump({"email": EMAIL, "invite": INVITE, "proxy": PROXY,
                       "clicked": claimed_btn, "turnstile": ts,
                       "before": before, "after": after}, f, indent=2)
        print(f"\nsaved: {BASE}/data/v8_result.json")
        print(f"       {NET_LOG}")
        print(f"       {BASE}/shots/v8_final.png")
        netf.close()
        await asyncio.sleep(20)
        await ctx.close()

asyncio.run(main())
