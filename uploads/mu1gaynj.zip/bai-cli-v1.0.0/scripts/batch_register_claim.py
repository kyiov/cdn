#!/usr/bin/env python3
"""
BAI batch register + claim (verified-working flow combined).

Per account (from data/accounts.txt, lines "email|password"):
   1. fresh Chrome profile under profiles/acct_<suffix>
   2. Google OAuth login -> this registers/restores the BAI session for that Google acct
   3. apply invite code QC5MGL (the referral)
   4. go to /invite, read registration_reward state
   5. if claimable & not claimed -> open gift modal -> solve Turnstile (2captcha)
      -> feed token via widget callback (unlocks the Claim button) -> click Claim
   6. re-query /invite/my-registration and confirm claimed == true
   7. append a result line to data/batch_result.jsonl

Proxy handling: pick a random working proxy per account; if the page fails to
load (diagnosed by body length / title), retry with another proxy, and fall
back to direct after N proxy failures. Rotating matters because the signup
reward is rate-limited per IP (idx_signup_bonus_ip_limits_ip_created_at).

Usage:
    batch_register_claim.py                 # all accounts in data/accounts.txt
    batch_register_claim.py --only <email>  # single
    batch_register_claim.py --limit N       # first N accounts
"""
import asyncio, hashlib, json, os, random, shutil, sys, time, urllib.request
# Attempt to import playwright; if unavailable, set flag
try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
except Exception as e:
    PLAYWRIGHT_AVAILABLE = False
    PLAYWRIGHT_ERROR = str(e)

# ───────────── Rich TUI kit (scripts/ui.py) — fallback otomatis ─────────────
import importlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ui = importlib.import_module("ui")
say = ui.say          # print → masuk card aktif kalau ada (mode batch)

# proxy buat kompatibilitas modul yang masih import helper lama
_hdr = ui.fmt
_ok   = lambda t: ui.fmt(t, "ok", True)
_warn = lambda t: ui.fmt(t, "warn")
_err  = lambda t: ui.fmt(t, "err", True)
_info = lambda t: ui.fmt(t, "info")
_dim  = lambda t: ui.fmt(t, "dim")
_tag  = _ok
_fail = _err

BASE      = os.environ.get("BAI_BASE", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ACCOUNTS  = os.environ.get("BAI_ACCOUNTS", f"{BASE}/data/accounts.txt")
RESULT    = os.environ.get("BAI_RESULT", f"{BASE}/data/batch_result.jsonl")
PROXIES   = os.environ.get("BAI_PROXIES", f"{BASE}/data/proxies_working.txt")
INVITE    = os.environ.get("BAI_INVITE", "QC5MGL")
CAP_KEY   = os.environ.get("BAI_CAPKEY", "")   # isi lewat config.toml [solver] / env
SITEKEY   = os.environ.get("BAI_SITEKEY", "0x4AAAAAADKhTSXIozuHjOoF")
CHAT_URL  = "https://chat.b.ai/chat"
INVITE_URL= "https://chat.b.ai/invite"
UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36")
NEW_PROFILE = os.environ.get("BAI_PROFILE_TMP", "/tmp/bai_batch_<suffix>")
APIKEY_OUT  = os.environ.get("BAI_APIKEY_OUT", f"{BASE}/data/api_keys.json")
APKEY_ONLY  = False   # set to True via --apikey-only: skip login/claim, just make keys

# ---------------------------------------------------------------- inject (9router)
# Per-key inject ke DB 9router (dari bai_cli.py via BAI_INJECT_* env).
INJECT          = os.environ.get("BAI_INJECT", "0") == "1"
INJECT_DBS      = [p for p in os.environ.get("BAI_INJECT_DB_PATHS", "").split(os.pathsep) if p]
INJECT_MODEL    = os.environ.get("BAI_INJECT_MODEL", "glm-5.3-flash")
INJECT_BASE     = os.environ.get("BAI_INJECT_BASE_URL", "https://api.b.ai/v1")
INJECT_PREFIX   = os.environ.get("BAI_INJECT_PREFIX", "bai")
INJECT_NUMBERED = os.environ.get("BAI_INJECT_NUMBERED", "1") == "1"
INJECT_AUTO_RESTART = os.environ.get("BAI_INJECT_AUTO_RESTART", "0") == "1"
INJECTED_ANY    = False

# ---------------------------------------------------------------- turnstile hook
# Stub window.turnstile BEFORE app JS runs: capture the widget's callback in
# render(), then __tsFeed() injects the solved token AND fires that callback.
# Feeding the callback is what actually enables the Claim button (setting the
# hidden input alone does nothing).
INIT_JS = r"""
(() => {
  window.__ts = {calls: [], log: []};
  const api = {
    render(container, params) {
      const id = 'ts_' + window.__ts.calls.length;
      window.__ts.calls.push({
        id: id,
        sitekey: params && params.sitekey,
        action: (params && params.action) || null,
        cData: (params && params.cData) || null,
        _cb: params && params.callback,
        token: null,
      });
      window.__ts.log.push('render ' + id + ' sitekey=' + (params && params.sitekey));
      try {
        const el = typeof container === 'string'
          ? document.querySelector(container) : container;
        if (el && !el.querySelector('input[name="cf-turnstile-response"]')) {
          const i = document.createElement('input');
          i.type = 'hidden'; i.name = 'cf-turnstile-response';
          el.appendChild(i);
        }
      } catch (e) {}
      return id;
    },
    reset() {}, remove() {},
    getResponse(id) {
      const c = window.__ts.calls.find(x => x.id === id) || window.__ts.calls[0];
      return (c && c.token) || '';
    },
    isExpired() { return false; },
    ready(cb) { try { cb(); } catch (e) {} },
    execute(c, p) { return api.render(c, p); },
  };
  Object.defineProperty(window, 'turnstile', {
    configurable: true,
    get() { return api; },
    set(v) { window.__ts.log.push('blocked overwrite of window.turnstile'); },
  });
  window.__tsFeed = (token, idx) => {
    const c = window.__ts.calls[idx || 0];
    if (!c) return 'no-widget-registered';
    c.token = token;
    document.querySelectorAll(
      'input[name="cf-turnstile-response"],textarea[name="cf-turnstile-response"]'
    ).forEach(el => {
      el.value = token;
      el.dispatchEvent(new Event('input', {bubbles: true}));
      el.dispatchEvent(new Event('change', {bubbles: true}));
    });
    if (typeof c._cb === 'function') {
      try { c._cb(token); return 'callback-fired'; }
      catch (e) { return 'callback-threw: ' + e; }
    }
    return 'no-callback-registered';
  };
})();
"""

# read state of registration_reward via the live tRPC session + apiAccessToken
CHECK_JS = r"""
async () => {
  const u = '/trpc/lambda/user.getUserState?input=' +
            encodeURIComponent(JSON.stringify({json:null, meta:{values:['undefined']}}));
  const r0 = await fetch(u, {credentials:'include'});
  const j0 = await r0.json();
  const d0 = j0?.result?.data?.json || {};
  const tok = d0.apiAccessToken;
  if (!tok) return {error:'no apiAccessToken', status:r0.status};
  const r = await fetch('https://api.b.ai/api/activity/invite/my-registration',
                        {headers:{'X-Ainft-Auth-Token':'Bearer '+tok}});
  const body = await r.json();
  return {userId: d0.userId, email: d0.email, status: r.status, reg: body?.data};
}
"""

DUMP_JS = r"""
() => Array.from(document.querySelectorAll('button')).map((b,i) => ({
  i, text:(b.textContent||'').trim().slice(0,40),
  visible: !!b.offsetParent,
  disabled: b.disabled || b.getAttribute('aria-disabled') === 'true',
})).filter(b => b.visible && b.text)
"""

# Hydration marker: the app shell is a Next.js SPA with no text until React
# hydrates, so bodyLen is NOT a valid load signal. Poll for app markers instead.
APP_MARKER = r"""
() => {
  const btns = Array.from(document.querySelectorAll('button'))
                  .filter(b => b.offsetParent)
                  .map(b => (b.textContent || '').trim());
  const txt = (document.body?.innerText || '');
  return {
    url: location.href,
    title: document.title,
    bodyLen: txt.length,
    hydrated: btns.some(t => ['Log in','Sign in','New Chat','APP'].includes(t))
              || txt.includes('Log in') || txt.includes('New Chat'),
    buttons: btns.slice(0, 30),
    head: txt.slice(0, 200),
  };
}
"""

async def wait_hydrated(page, timeout_s=25):
    """Wait until the SPA renders its app markers. Returns the marker dict,
    or None on timeout (page failed to load / proxy broken)."""
    for _ in range(timeout_s * 2):
        m = await page.evaluate(APP_MARKER)
        if m.get("hydrated"):
            return m
        await page.wait_for_timeout(500)
    return None

# ---------------------------------------------------------------- 2captcha
def cap(path, payload):
    req = urllib.request.Request(
        f"https://api.2captcha.com/{path}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=40) as r:
        return json.loads(r.read().decode())


def solve_turnstile():
    task = {"type": "TurnstileTaskProxyless",
            "websiteURL": INVITE_URL, "websiteKey": SITEKEY}
    r = cap("createTask", {"clientKey": CAP_KEY, "task": task})
    tid = r.get("taskId")
    if not tid:
        return None, f"createTask failed: {r}"
    t0 = time.time()
    for _ in range(45):
        time.sleep(4)
        res = cap("getTaskResult", {"clientKey": CAP_KEY, "taskId": tid})
        if res.get("status") == "ready":
            tok = res["solution"]["token"]
            return tok, f"solved in {int(time.time()-t0)}s"
        if res.get("errorId"):
            return None, f"2captcha error: {res}"
    return None, "2captcha timeout"


# ---------------------------------------------------------------- api key
async def create_api_key(context, name, group="default"):
    """Create a BAI API key via the live tRPC endpoint.

    Uses the browser context's session cookie (__Secure-authjs.session-token)
    — no turnstile/captcha, no X-Ainft-Auth-Token. Verified against the real UI.
    """
    import urllib.parse
    try:
        cookies = await context.cookies("https://chat.b.ai")
    except Exception as e:
        return None, f"read cookies: {e}"
    sess = next((c["value"] for c in cookies
                 if c["name"] == "__Secure-authjs.session-token"), None)
    if not sess:
        return None, "no __Secure-authjs.session-token cookie"

    body = json.dumps({"0": {"json": {"group": group, "name": name}}})
    req = urllib.request.Request(
        "https://chat.b.ai/trpc/lambda/apiKey.createApiKey?batch=1",
        data=body.encode(),
        headers={
            "Content-Type": "application/json",
            "Cookie": f"__Secure-authjs.session-token={sess}",
            "User-Agent": UA,
        },
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            resp = json.loads(r.read().decode())
    except Exception as e:
        return None, f"create request: {e}"

    try:
        data = resp[0]["result"]["data"]["json"]
        return data.get("key"), data
    except Exception as e:
        return None, f"parse resp: {e} | {json.dumps(resp)[:300]}"


def save_api_key(email, key, meta):
    """Append an account's created API key to data/api_keys.json."""
    recs = []
    if os.path.exists(APIKEY_OUT):
        try:
            recs = json.load(open(APIKEY_OUT))
            if not isinstance(recs, list):
                recs = []
        except Exception:
            recs = []
    # dedupe by email (keep the newest key for that account)
    recs = [r for r in recs if r.get("email") != email]
    recs.append({"email": email, "key": key, "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                 "group": (meta or {}).get("group"), "id": (meta or {}).get("id")})
    with open(APIKEY_OUT, "w") as f:
        json.dump(recs, f, indent=2)
    return recs


def _inject_key(email, key):
    """Inject one fresh key into every configured 9router DB. Best-effort:
    never fails the account flow; gateway restart happens once at batch end."""
    global INJECTED_ANY
    if not INJECT_DBS:
        say("[inject] skip: BAI_INJECT_DB_PATHS kosong", color="warn")
        return
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import importlib
        nine = importlib.import_module("9router_inject")
        res = nine.inject_to_devices(
            [{"email": email, "key": key}], INJECT_DBS,
            default_model=INJECT_MODEL, base_url=INJECT_BASE,
            prefix=INJECT_PREFIX, numbered=INJECT_NUMBERED,
            auto_restart=False)
        for r in res:
            say(f"inject {r['db']}: {_tag(r['status']) if r['status'].startswith('injected') else _dim(r['status'])}")
            if r["status"].startswith("injected"):
                INJECTED_ANY = True
    except Exception as e:
        say(f"[inject] error: {e}", color="err")


async def try_make_api_key(ctx, email, suffix, res):
    """Create an API key for the account and record it. Best-effort (never fails the run)."""
    try:
        key, meta = await create_api_key(ctx, f"batch-{suffix}")
    except Exception as e:
        res["api_key_error"] = f"create except: {e}"
        say(f"API key FAILED: {e}", color="err")
        return
    if key:
        res["api_key"] = key
        res["api_key_id"] = (meta or {}).get("id")
        save_api_key(email, key, meta)
        say(f"API key created: {key[:16]}... (id {res['api_key_id']})", color="ok")
        if INJECT:
            _inject_key(email, key)
    else:
        res["api_key_error"] = meta
        say(f"API key FAILED: {meta}", color="err")


# ---------------------------------------------------------------- browser helpers
async def click_text(page, texts, timeout=1500, label=""):
    """Try a list of button texts, click the first visible one."""
    for t in texts:
        try:
            b = page.locator(f"button:has-text('{t}')").first
            if await b.is_visible(timeout=timeout):
                await b.click()
                await page.wait_for_timeout(1500)
                return t
        except Exception:
            pass
    return None


async def _wait_url_change(g, before, timeout_ms):
    """Wait until the popup URL changes or the popup closes."""
    for _ in range(max(1, timeout_ms // 500)):
        try:
            if g.url.lower() != before:
                return True
            await g.wait_for_timeout(500)
        except Exception:
            return True  # popup closed (callback fired)
    return False

# ---------------------------------------------------------------- debug tracing
DEBUG   = os.environ.get("BAI_DEBUG", "0") == "1"
DBG_DIR = "/tmp/bai_debug"

async def dbg(ctx, label):
    """If BAI_DEBUG=1, dump every page (URL/title/body snippet) + screenshot."""
    if not DEBUG:
        return
    os.makedirs(DBG_DIR, exist_ok=True)
    try:
        for i, p in enumerate(ctx.pages):
            try:
                u = p.url or "?"
                t = await p.title()
                body = ""
                try:
                    body = (await p.inner_text("body")).replace("\n", " | ")[:300]
                except Exception:
                    pass
                await p.screenshot(path=f"{DBG_DIR}/{label}_p{i}.png")
                say(f"[dbg] {label} page{i}: url={u[:140]}", color="dim")
                say(f"      title={t!r}", color="dim")
                say(f"      body={body!r}", color="dim")
            except Exception as e:
                say(f"[dbg] {label} page{i} err: {e}", color="dim")
    except Exception as e:
        say(f"[dbg] {label} ctx err: {e}", color="dim")


async def google_login(page, ctx, email, password):
    """OAuth login for a Google account; registers/restores the BAI session.
    Uses the hand-verified deterministic sequence (see _cb_trace2): open popup,
    identifier -> password -> interstitial click(s) -> wait for the main-page
    POST /api/auth/callback/google-gis which sets __Secure-authjs.session-token.
    Never reload/close the main page before that callback fires."""
    # 1. Open the login modal.
    if not await click_text(page, ["Log in", "Sign in"], 8000):
        await dbg(ctx, "01_nologinbtn")
        return False, "no Log in button"
    await page.wait_for_timeout(1200)
    await dbg(ctx, "02_loginmodal")

    # 2. Referral code (MUST bind account to invite).
    try:
        for sel in ["button:has-text('Referral Code')", "button:has-text('Referral')"]:
            b = page.locator(sel).first
            if await b.count() > 0 and await b.is_visible(timeout=1500):
                await b.click()
                await page.wait_for_timeout(500)
                break
        for sel in ["input[placeholder='Enter referral code']",
                    "input[name='referral_code']", "input[placeholder*='referral']"]:
            inp = page.locator(sel).first
            if await inp.count() > 0 and await inp.is_visible(timeout=1500):
                await inp.fill(INVITE)
                say(f"invite_code {INVITE} terisi di modal login", color="ok")
                break
    except Exception as e:
        say(f"[invite] err: {e}", color="err")
    await page.wait_for_timeout(400)

    # 3. Open the Google popup.
    try:
        async with ctx.expect_page(timeout=20000) as pinfo:
            await page.locator("button:has-text('Google')").first.click()
        g = await pinfo.value
    except Exception as e:
        await dbg(ctx, "03_popupfail")
        return False, f"Google popup: {e}"
    await g.wait_for_load_state("domcontentloaded")
    await g.wait_for_timeout(4000)
    await dbg(ctx, "04_popupopen")

    # 4. Identifier (email). Fresh accounts use input#identifierId.
    if "identifier" in g.url.lower() or await g.locator("input#identifierId").count():
        await g.fill("input#identifierId", email, timeout=8000)
        await click_text(g, ["Next", "Berikutnya"], label="google ")
        await g.wait_for_timeout(4500)
        await dbg(ctx, "05_emailnext")

    # 5. Password.
    if any(k in g.url.lower() for k in ("challenge", "pwd")):
        await g.fill("input[name='Passwd']", password, timeout=8000)
        await click_text(g, ["Next", "Berikutnya"], label="google ")
        await g.wait_for_timeout(6000)
        await dbg(ctx, "06_pwdnext")

    # 6. Walk interstitials deterministically: accept speedbump if shown, then
    #    click the consent button, until the popup lands on gsi/transform/callback.
    #
    #    click_text() swallows its first locator timeout, so use the visible
    #    button list instead and wait for the URL to actually change — the old
    #    loop clicked nothing and the speedbump page never advanced.
    for _ in range(14):
        try:
            u = g.url.lower()
        except Exception:
            break  # popup closed -> callback fired
        # NOTE: no URL-based break here. Google query strings contain
        # "chat.b.ai" (app_domain) and "gis_transform" (redirect_uri) on the
        # speedbump page itself, so any substring check breaks too early.
        # Classify the page instead; success = popup closes.
        if any(k in u for k in ("speedbump", "termsofservice", "workspace")):
            say("accepting Workspace terms...", color="warn")
            texts = ["I understand", "Saya mengerti", "Mengerti", "Accept",
                     "Agree", "I agree"]
        elif any(k in u for k in ("oauth", "consent")):
            say("clicking continue...", color="warn")
            texts = ["Lanjutkan", "Continue", "Allow", "Izinkan", "Setuju"]
        else:
            texts = []
        clicked = False
        if texts:
            try:
                vis = await g.evaluate(
                    """(ts) => {
                      const btns = Array.from(document.querySelectorAll('button'));
                      for (const b of btns) {
                        const t = (b.textContent || '').trim();
                        if (b.offsetParent && ts.includes(t)) return t;
                      }
                      return null;
                    }""", texts)
            except Exception:
                break  # popup navigated/closed -> callback fired
            if vis:
                await g.locator(f"button:has-text('{vis}')").first.click()
                clicked = True
                say(f"clicked '{vis}'", color="info")
        # wait for the URL to change (or the popup to close on callback)
        if clicked:
            before = u
            if not await _wait_url_change(g, before, 15000):
                say("URL did not change; continuing", color="warn")
            else:
                say(f"advanced -> {(g.url or 'closed')[:80]}", color="info")
        else:
            try:
                await g.wait_for_timeout(1500)
            except Exception:
                break

    await dbg(ctx, "07_interstitial_done")

    # 7. Wait for the callback to set the session cookie. No reload here.
    for _ in range(25):
        try:
            ck = await ctx.cookies("https://chat.b.ai")
            if any("session-token" in c["name"] for c in ck):
                return True, "session cookie set (callback ok)"
        except Exception:
            pass
        await page.wait_for_timeout(1000)

    # fallback: poll the session API (no reload).
    for i in range(20):
        await page.wait_for_timeout(1000)
        try:
            has_session = await page.evaluate(
                """async () => {
                  const r = await fetch('/api/auth/session', {credentials:'include'});
                  const j = await r.json();
                  return !!(j && (j.user || j.session));
                }""")
        except Exception:
            has_session = False
        if has_session:
            return True, f"logged in after {i+1}s"
    await dbg(ctx, "08_sessionfail")
    return False, "session never established"


# ---------------------------------------------------------------- core per-account
async def handle_account(p, email, password, suffix, proxies, max_proxy_tries=3):
    """Full register+claim for one account. Returns a result dict."""
    res = {"email": email, "suffix": suffix, "ok": False,
           "started": time.strftime("%H:%M:%S")}

    # --- try proxies, then direct ---
    proxy_pool = list(proxies)
    chosen_proxy = None
    for attempt in range(max_proxy_tries + 1):
        chosen_proxy = random.choice(proxy_pool) if proxy_pool else None
        if chosen_proxy:
            proxy_pool.remove(chosen_proxy)
        kw = dict(
            headless=True,
            args=["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport={"width": 1280, "height": 900},
            user_agent=UA,
        )
        if chosen_proxy:
            kw["proxy"] = {"server": chosen_proxy}

        run = NEW_PROFILE.replace("<suffix>", suffix)
        if os.path.exists(run):
            shutil.rmtree(run)
        os.makedirs(run, exist_ok=True)

        try:
            ctx = await p.chromium.launch_persistent_context(run, **kw)
        except Exception as e:
            res.setdefault("errors", []).append(f"launch: {e}")
            continue

        await ctx.add_init_script(INIT_JS)
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()

        try:
            await page.goto(CHAT_URL, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            await ctx.close()
            res.setdefault("errors", []).append(f"goto: {e}")
            continue

        m = await wait_hydrated(page)
        if not m:
            await ctx.close()
            res.setdefault("errors", []).append(
                f"page never hydrated (proxy {chosen_proxy}) bodyLen={m and m['bodyLen']}")
            continue  # try next proxy

        # reached here: page loaded okay
        res["proxy"] = chosen_proxy
        res["load"] = "proxy" if chosen_proxy else "direct"
        res["hydrated"] = {"bodyLen": m["bodyLen"],
                           "buttons": m["buttons"][:15]}
        return await do_account_flow(page, ctx, email, password, suffix, res)

    res["ok"] = False
    res["error"] = "all proxies failed to load page"
    return res


async def do_account_flow(page, ctx, email, password, suffix, res):
    """Login + claim on an already-loaded page. Returns result dict."""
    try:
        _p = ui.active_card()
        if _p:
            _p.progress(0, 5)

        logged, msg = await google_login(page, ctx, email, password)
        if not logged:
            res["error"] = f"login: {msg}"
            await ctx.close()
            return res

        res["login"] = "ok"
        if _p:
            _p.progress(1, 5)

        # dismiss welcome/consent modal (if any)
        await click_text(page, ["Got it", "Mengerti", "OK", "Start"], 5000)
        await page.wait_for_timeout(1500)

        # navigate to /invite (claim UI only lives here)
        await page.goto(INVITE_URL, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(6000)

        before = await page.evaluate(CHECK_JS)
        reg = (before.get("reg") or {}).get("registration_reward") or {}
        res["before"] = reg

        if reg.get("claimed"):
            res["status"] = "already_claimed"
            res["ok"] = True
            if _p:
                _p.progress(5, 5)
            # session is live; just make the API key for this account
            await try_make_api_key(ctx, email, suffix, res)
            await ctx.close()
            return res

        if not reg.get("claimable"):
            res["status"] = "not_claimable"
            res["error"] = f"state: {json.dumps(reg)[:200]}"
            await ctx.close()
            return res

        if _p:
            _p.progress(2, 5)

        # open the gift modal
        c = await click_text(page, ["Claim Free Credits", "Claim Credits"], 8000)
        if not c:
            res["status"] = "no_claim_button"
            res["error"] = "Claim Free Credits not visible"
            await ctx.close()
            return res
        await page.wait_for_timeout(5000)

        # grab the turnstile params captured by the hook
        ts = await page.evaluate(
            "() => window.__ts ? window.__ts.calls.map(c => "
            "({sitekey:c.sitekey, action:c.action, cData:c.cData, "
            " hasCb: typeof c._cb==='function'})) : []")
        if not ts:
            res["status"] = "no_turnstile"
            res["error"] = "turnstile widget never rendered"
            await ctx.close()
            return res

        tok, s_msg = solve_turnstile()
        res["solve"] = s_msg
        if not tok:
            res["status"] = "solve_failed"
            res["error"] = s_msg
            await ctx.close()
            return res

        if _p:
            _p.progress(3, 5)

        fed = await page.evaluate("([t,i])=>window.__tsFeed(t,i)", [tok, 0])
        res["feed"] = fed
        await page.wait_for_timeout(4000)

        # click the exact Claim button by index (has-text('Claim') matches
        # 'Claim Free Credits' first; index click avoids that)
        btns = await page.evaluate(DUMP_JS)
        target = next((b for b in btns
                       if b["text"].strip().lower() in ("claim", "klaim",
                                                        "confirm", "submit")
                       and not b["disabled"]), None)
        if not target:
            res["status"] = "no_enabled_claim"
            res["error"] = "no enabled Claim button after token feed"
            await ctx.close()
            return res

        await page.evaluate("(i)=>document.querySelectorAll('button')[i].click()",
                            target["i"])
        await page.wait_for_timeout(5000)

        if _p:
            _p.progress(4, 5)

        # poll until claimed:true (fulfillment can be pending for a few seconds)
        for poll in range(8):
            after = await page.evaluate(CHECK_JS)
            reg2 = (after.get("reg") or {}).get("registration_reward") or {}
            if reg2.get("claimed"):
                break
            await page.wait_for_timeout(3000)
        else:
            after = await page.evaluate(CHECK_JS)
            reg2 = (after.get("reg") or {}).get("registration_reward") or {}
        res["after"] = reg2

        if reg2.get("claimed"):
            res["status"] = "claimed"
            res["ok"] = True
            if _p:
                _p.progress(5, 5)
            await try_make_api_key(ctx, email, suffix, res)
        else:
            res["status"] = "claim_unconfirmed"
            res["error"] = f"after: {json.dumps(reg2)[:200]}"

        await ctx.close()
        return res
    except Exception as e:
        res["ok"] = False
        res["error"] = f"exception: {e}"
        try:
            await ctx.close()
        except Exception:
            pass
        return res


# ---------------------------------------------------------------- main
async def main():
    if not PLAYWRIGHT_AVAILABLE:
        say("Playwright not available: " + PLAYWRIGHT_ERROR, color="err")
        say("Please install: pip install playwright && python -m playwright install chromium", color="dim")
        return
    accounts = []
    with open(ACCOUNTS) as f:
        for line in f:
            line = line.strip()
            if not line or "|" not in line:
                continue
            email, password = line.split("|", 1)
            accounts.append((email.strip(), password.strip()))

    # CLI filters
    if "--only" in sys.argv:
        only = sys.argv[sys.argv.index("--only") + 1]
        accounts = [a for a in accounts if a[0] == only]
    if "--limit" in sys.argv:
        n = int(sys.argv[sys.argv.index("--limit") + 1])
        accounts = accounts[:n]
    APKEY_ONLY = "--apikey-only" in sys.argv
    ### set module-level flag (do_account_flow reads it)
    globals()["APKEY_ONLY"] = APKEY_ONLY

    proxies = []
    if os.path.exists(PROXIES):
        with open(PROXIES) as f:
            proxies = [l.strip() for l in f if l.strip()]

    # banner cardbox + sound mulai
    ui.banner_panel(
        title="BAI · BATCH",
        tag="auto register · claim · key · inject",
        stats=ui.stats_line(akun=len(accounts), proxy=len(proxies),
                            invite=INVITE, inject=INJECT),
        start=True)

    # Retry count for flaky Google login (speedbump click / proxy hiccups).
    MAX_ATTEMPTS = int(os.environ.get("BAI_MAX_ATTEMPTS", "3"))
    RETRY_DELAY_S = int(os.environ.get("BAI_RETRY_DELAY_S", "20"))

    completed = 0
    rows = []                     # hasil utk tabel akhir
    res_cache = []                # dict hasil tiap akun (utk ringkasan)
    async with async_playwright() as p:
        for i, (email, password) in enumerate(accounts, start=1):
            suffix = hashlib.md5(email.encode()).hexdigest()[:8]

            # buka card akun (semua say() selama akun ini masuk ke card ini)
            card = ui.set_account(email, total=len(accounts), idx=i)
            card.say(f"profile: {suffix}", color="dim")
            card.say("menyiapkan browser + proxy…", color="info")

            res = None
            for attempt in range(1, MAX_ATTEMPTS + 1):
                if attempt > 1:
                    card.say(f"[retry] attempt {attempt}/{MAX_ATTEMPTS} in "
                             f"{RETRY_DELAY_S}s (flaky Google login)...", color="warn")
                    await asyncio.sleep(RETRY_DELAY_S)

                res = await handle_account(p, email, password, suffix, proxies)
                if res.get("ok"):
                    break

                # Log failures per attempt (capped to keep the jsonl readable).
                if res.get("error"):
                    card.say(f"[attempt {attempt}] {res['error']}", color="warn")

                # Clean the /tmp profile so the next attempt starts fresh.
                prof = NEW_PROFILE.replace("<suffix>", suffix)
                if os.path.exists(prof):
                    try:
                        shutil.rmtree(prof)
                    except Exception:
                        pass

            # NOTE: no longer persist the profile to BASE/profiles/ — we always
            # do a fresh headless login per account (no session reuse). So the
            # /tmp working profile is just cleaned up below.
            if os.path.exists(NEW_PROFILE.replace("<suffix>", suffix)):
                try:
                    shutil.rmtree(NEW_PROFILE.replace("<suffix>", suffix))
                except Exception:
                    pass

            res["finished"] = time.strftime("%H:%M:%S")
            with open(RESULT, "a") as f:
                f.write(json.dumps(res) + "\n")

            status = res.get("status") or res.get("error") or "?"
            if res.get("ok"):
                card.say(f"status: {status}", color="ok")
                card.set_status("ok")
                ui.ok_sound()
            else:
                card.say(f"status: {status}", color="err")
                if res.get("error"):
                    card.say(f"err: {res['error']}", color="err")
                card.set_status("fail")
                ui.fail_sound()
            rows.append((str(i), email, f"[{'ok' if res.get('ok') else 'err'}]{status}[/{'ok' if res.get('ok') else 'err'}]",
                         res.get("finished", "")))
            res_cache.append(res)
            completed += 1

            # tutup card akun ini sebelum jeda / akun berikutnya
            ui.end_card()

            # small stagger between accounts (IP-limit + Google throttle safety)
            await asyncio.sleep(random.uniform(5, 12))

    # restart gateway ONCE after the batch (9router caches models at boot)
    if INJECT and INJECT_AUTO_RESTART and INJECTED_ANY:
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import importlib
            nine = importlib.import_module("9router_inject")
            say("[inject] restart 9router biar provider bai/* ke-load...", color="info")
            nine.restart_9router()
        except Exception as e:
            say(f"[inject] restart error: {e}", color="err")

    # tabel ringkasan + sound selesai
    ui.result_table(rows, title="HASIL BATCH")
    ui.summary_table({
        "total": completed,
        "ok": sum(1 for r in res_cache if r.get("ok")),
        "fail": sum(1 for r in res_cache if not r.get("ok")),
        "claimed": sum(1 for r in res_cache if r.get("status") == "claimed"),
        "keys": sum(1 for r in res_cache if r.get("api_key")),
    }, title="RINGKASAN")
    ui.done_sound()
    if not ui.rich_ok:
        print(f"  done: {completed} account(s); log -> {RESULT}")
