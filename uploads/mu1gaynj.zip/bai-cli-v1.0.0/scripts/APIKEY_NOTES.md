BAI API key endpoint — VERIFIED (captured from live UI, not guessed)

Create:
    POST https://chat.b.ai/trpc/lambda/apiKey.createApiKey?batch=1
    Cookie: __Secure-authjs.session-token=<session from BAI login>
    Body (JSON):
        {"0":{"json":{"group":"default","name":"<key name>"}}}

    NOTE: the body is the raw tRPC "batch" format — the key "0" is the
    operation index, and the whole thing is ONE JSON object (not an array,
    though tRPC batches normally use arrays). This matches what the recorder
    captured verbatim.

    Response (tRPC envelope):
        [{"result":{"data":{"json":{
            "id":<int>,
            "name":"<key name>",
            "key":"sk-<FULL_KEY>",      <- the actual usable key
            "maskedKey":"sk-bmy1p*******ma09",
            "keyHash":"<sha256>",
            "group":"default",
            "enabled":true,
            "expiresAt":null,
            "userId":"user_...",
            ...
        }}}}]

List:
    GET https://chat.b.ai/trpc/lambda/apiKey.getApiKeys?batch=1&input=...
    Resp: {"0":{"result":{"data":{"json":[ {api key objects...} ]}}}}

Important notes:
- `group` = "default" gives 46 models, official API access, max availability.
- No Turnstile / captcha required. Just the session cookie.
- The `.key` field comes back ONCE on create (and in list it's returned as
  the full value too in some builds; safe to read from create response).
- tRPC calls are relative to chat.b.ai and use the session cookie, NOT an
  X-Ainft-Auth-Token header (that header is only for api.b.ai activity APIs).
- Rate limit / anti-abuse: none observed; trivial to batch.
