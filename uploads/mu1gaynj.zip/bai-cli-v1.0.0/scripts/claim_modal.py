#!/usr/bin/env python3
"""
Inspect the claim modal precisely: dump every button with its disabled state
before and after feeding the turnstile token, then click the real Claim
button via JS. Records the POST body.
"""
import asyncio, json, os, shutil, time, urllib.request
from playwright.async_api import async_playwright

BASE    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC     = "/tmp/bai_v8_run"
RUN     = "/tmp/bai_modal_run"
CAP_KEY = os.environ.get("BAI_CAPKEY", "")   # isi lewat config/env
URL     = "https://chat.b.ai/invite"
UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36")

INIT_JS = open(f"{BASE}/scripts/_ts_hook.js").read() if os.path.exists(
    f"{BASE}/scripts/_ts_hook.js") else r"""
(() => {
  window.__ts = {calls: [], log: []};
  const api = {
    render(c, p) {
      const id = 'ts_' + window.__ts.calls.length;
      window.__ts.calls.push({id, sitekey: p&&p.sitekey, action:(p&&p.action)||null,
        cData:(p&&p.cData)||null, _cb: p&&p.callback, token:null});
      window.__ts.log.push('render '+id);
      try {
        const el = typeof c === 'string' ? document.querySelector(c) : c;
        if (el && !el.querySelector('input[name="cf-turnstile-response"]')) {
          const i=document.createElement('input');
          i.type='hidden'; i.name='cf-turnstile-response'; el.appendChild(i);
        }
      } catch(e){}
      return id;
    },
    reset(){}, remove(){},
    getResponse(id){const c=window.__ts.calls.find(x=>x.id===id)||window.__ts.calls[0];return (c&&c.token)||'';},
    isExpired(){return false;}, ready(cb){try{cb();}catch(e){}},
    execute(c,p){return api.render(c,p);},
  };
  Object.defineProperty(window,'turnstile',{configurable:true,get(){return api;},set(v){}});
  window.__tsFeed=(tok,i)=>{
    const c=window.__ts.calls[i||0];
    if(!c) return 'no-widget';
    c.token=tok;
    document.querySelectorAll('input[name="cf-turnstile-response"],textarea[name="cf-turnstile-response"]')
      .forEach(el=>{el.value=tok;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));});
    if(typeof c._cb==='function'){try{c._cb(tok);return 'callback-fired';}catch(e){return 'threw: '+e;}}
    return 'no-callback';
  };
})();
"""

DUMP_JS = r"""
() => Array.from(document.querySelectorAll('button')).map((b,i) => ({
  i, text: (b.textContent||'').trim().slice(0,40),
  visible: !!b.offsetParent,
  disabled: b.disabled || b.getAttribute('aria-disabled') === 'true',
  cls: (b.className||'').toString().slice(0,60),
})).filter(b => b.visible && b.text)
"""

STATE_JS = r"""
async () => {
  const u='/trpc/lambda/user.getUserState?input='+encodeURIComponent(JSON.stringify({json:null,meta:{values:['undefined']}}));
  const d=(await (await fetch(u,{credentials:'include'})).json())?.result?.data?.json||{};
  if(!d.apiAccessToken) return {error:'no token'};
  const r=await fetch('https://api.b.ai/api/activity/invite/my-registration',
      {headers:{'X-Ainft-Auth-Token':'Bearer '+d.apiAccessToken}});
  return (await r.json())?.data?.registration_reward;
}
"""


def cap(path, payload):
    req = urllib.request.Request(f"https://api.2captcha.com/{path}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type":"application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=40) as r:
        return json.loads(r.read().decode())


def solve(sitekey, action=None, cdata=None):
    t = {"type":"TurnstileTaskProxyless","websiteURL":URL,"websiteKey":sitekey}
    if action: t["action"]=action
    if cdata:  t["data"]=cdata
    tid = cap("createTask",{"clientKey":CAP_KEY,"task":t}).get("taskId")
    print(f"    task={tid}")
    if not tid: return None
    t0=time.time()
    for _ in range(45):
        time.sleep(4)
        res=cap("getTaskResult",{"clientKey":CAP_KEY,"taskId":tid})
        if res.get("status")=="ready":
            tok=res["solution"]["token"]
            print(f"    SOLVED {int(time.time()-t0)}s"); return tok
        if res.get("errorId"):
            print(f"    err {res}"); return None
    return None


async def main():
    if os.path.exists(RUN): shutil.rmtree(RUN)
    shutil.copytree(SRC, RUN, ignore=shutil.ignore_patterns("Singleton*"))

    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            RUN, headless=False,
            args=["--disable-blink-features=AutomationControlled"],
            ignore_default_args=["--enable-automation"],
            viewport={"width":1280,"height":900}, user_agent=UA)
        await ctx.add_init_script(INIT_JS)
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()

        posts = []

        async def on_req(r):
            if r.method == "POST" and any(k in r.url for k in ("claim","reward","invite")):
                try: b = r.post_data
                except Exception: b = None
                posts.append({"url": r.url, "body": b})
                print(f"\n  [POST] {r.url[:140]}")
                print(f"  [BODY] {(b or '<empty>')[:1500]}")

        async def on_resp(r):
            if "claim" in r.url:
                try: b = await r.text()
                except Exception: b = ""
                print(f"  [RESP {r.status}] {b[:600]}")

        page.on("request", lambda r: asyncio.create_task(on_req(r)))
        page.on("response", lambda r: asyncio.create_task(on_resp(r)))

        await page.goto(URL, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(8000)
        print(f"BEFORE: {json.dumps(await page.evaluate(STATE_JS))}")

        print("\n--- buttons on /invite ---")
        for b in await page.evaluate(DUMP_JS):
            print(f"  [{b['i']:>3}] dis={str(b['disabled']):<5} {b['text']!r}")

        # open the gift modal
        await page.locator("button:has-text('Claim Free Credits')").first.click()
        print("\n>>> clicked 'Claim Free Credits'")
        await page.wait_for_timeout(5000)

        print("\n--- buttons in modal (pre-token) ---")
        for b in await page.evaluate(DUMP_JS):
            print(f"  [{b['i']:>3}] dis={str(b['disabled']):<5} {b['text']!r}")

        ts = await page.evaluate("""() => window.__ts ? window.__ts.calls.map(
            c=>({id:c.id,sitekey:c.sitekey,action:c.action,cData:c.cData,
                 hasCb: typeof c._cb==='function'})) : []""")
        print(f"\nturnstile calls: {json.dumps(ts)}")

        if ts:
            tok = solve(ts[0]["sitekey"], ts[0].get("action"), ts[0].get("cData"))
            if tok:
                print(f"    feed -> {await page.evaluate('([t,i])=>window.__tsFeed(t,i)',[tok,0])}")
                await page.wait_for_timeout(4000)

        print("\n--- buttons in modal (post-token) ---")
        btns = await page.evaluate(DUMP_JS)
        for b in btns:
            print(f"  [{b['i']:>3}] dis={str(b['disabled']):<5} {b['text']!r}")

        # click the exact Claim button by index, via JS (bypasses overlay issues)
        target = next((b for b in btns
                       if b["text"].strip().lower() in ("claim","klaim","confirm","submit")
                       and not b["disabled"]), None)
        if target:
            print(f"\n>>> clicking [{target['i']}] {target['text']!r}")
            await page.evaluate(
                "(i)=>document.querySelectorAll('button')[i].click()", target["i"])
            await page.wait_for_timeout(8000)
        else:
            print("\n!!! no enabled Claim button found")

        after = await page.evaluate(STATE_JS)
        print(f"\nAFTER : {json.dumps(after)}")
        print("\n===== VERDICT =====")
        if isinstance(after, dict) and after.get("claimed"):
            print(">>> CLAIMED OK")
        else:
            print(">>> still not claimed")
        print(f"posts captured: {len(posts)}")
        for p_ in posts:
            print(f"  {p_['url'][:120]}\n    {(p_['body'] or '<empty>')[:1200]}")

        with open(f"{BASE}/data/modal_posts.json","w") as f:
            json.dump({"posts":posts,"after":after}, f, indent=2)
        await page.screenshot(path=f"{BASE}/shots/modal_final.png", full_page=True)
        await asyncio.sleep(20)
        await ctx.close()

asyncio.run(main())
