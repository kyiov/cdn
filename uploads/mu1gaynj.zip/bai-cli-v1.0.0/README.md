# BAI CLI — Auto Register · Claim · Create Key · Inject (9router)

CLI interactive untuk bikin akun chat.b.ai secara massal: daftar (Google OAuth),
claim 300k credits (pakai invite code), bikin API key, dan **inject key ke 9router**
supaya key langsung kepake lewat gateway lokal. Semua **headless** — browser gak muncul.

**TUI modern (Rich)**: banner + menu di dalam card box, tiap akun punya kartu
progres sendiri (spinner, log berjalan, progress bar), tabel ringkasan akhir,
plus **sound** ok/fail/start/done. Kalau output di-pipe atau `rich` belum
terinstall, otomatis fallback teks polos — log tetap lengkap.

## Hasil (verified, 2026-09-04)

- **10 akun** `akun*@example.com`, masing-masing:
  - Claim **300k credits** lewat invite code `QC5MGL`
  - **API key** aktif (prefix `sk-`), working di `api.b.ai/v1/chat/completions`
- **Injected ke 9router**: 24 provider `bai-1` .. `bai-13` + `bai-17` .. `bai-24`
  + `bai-27` .. `bai-29`, default model `glm-5.3-flash` → gateway expose
  **model `bai/*`** di `127.0.0.1:20128`
- Semua dijalankan **headless** (kepala browser gak munculin)

## Struktur

```
bai_cli.py                  # CLI interactive (menu 1-5)
config.example.toml         # template config — copy jadi config.toml lalu isi
.gitignore                  # jaga config.toml + data asli gak ke-commit
data/
  accounts.txt.example      # contoh format email|pass
  proxies_working.txt.example
data/                       # dibuat saat jalan (jangan di-commit):
  accounts.txt              # email|pass, satu per baris
  api_keys.json             # hasil API key per akun
  proxies_working.txt       # proxy pool (format http://host:port)
  batch_result.jsonl        # log per-akun (append)
scripts/
  ui.py                     # TUI kit (rich): banner, cardbox per akun, tabel, sound
  batch_register_claim.py   # flow utama: register+claim+key (verified)
  9router_inject.py         # inject key -> 9router sqlite
  claim_modal.py, bai_v8.py # komponen asli
NOTES.md                    # detail teknis + pitfalls
```

## Instalasi (sekali saja)

### 1. Prasyarat

- **Python 3.11+** (pake 3.12 di mesin ini). Cek: `python3 --version`
- **pip + venv** (biasanya udah bundled)
- **9router** udah ter-install kalau mau pakai fitur inject (path DB otomatis
  ke-detect, lihat `[inject]` di bawah)
- (opsional) **2captcha** account + key, buat solve Turnstile pas claim

### 2. Bikin virtualenv

> Jangan install langsung ke system python — di distro modern ada
> `externally-managed-environment` (PEP 668), pip bakal nolak. Pakai venv.

**Linux / macOS:**

```bash
cd /path/ke/project-kalian          # lokasi project kalian
python3 -m venv .venv
source .venv/bin/activate          # masuk venv
```

**Windows (PowerShell):**

```powershell
cd C:\path\to\bai                  # lokasi project kalian
python -m venv .venv
.venv\Scripts\Activate.ps1         # masuk venv
```

**Windows (CMD):**

```cmd
cd C:\path\to\bai
python -m venv .venv
.venv\Scripts\activate.bat
```

### 3. Install paket + browser (semua OS, di dalam venv)

```bash
# install paket python-nya (playwright + rich utk TUI modern)
pip install playwright rich

# download browser Chromium
python -m playwright install chromium
```

Catatan per OS:

- **Linux**: kalau Chromium gagal jalan (error shared library), install
  dependency sistem: `python -m playwright install-deps chromium`
  (butuh sudo). Di distro yang "tidak resmi didukung Playwright" (kernel
  custom dsb), Playwright otomatis download **fallback build ubuntu24.04**
  — itu normal, jalan aja.
- **Windows**: dua perintah di atas udah cukup. (Kalau pakai WSL, ikuti
  langkah Linux.)
- **macOS**: dua perintah di atas udah cukup.

> `bai_cli.py` otomatis cari python ber-playwright: urutannya `.venv/` di
> project → `/tmp/playwright-venv` → `~/.venv` → system python. Jadi selama
> `.venv` ada, script jalan normal tanpa perlu atur PATH — bahkan tanpa
> `activate` pun `python3 bai_cli.py` auto lompat ke venv project.

### 4. Siapkan config

Copy template config lalu isi — minimal **2captcha key** (buat claim) dan
pastikan **invite code** bener:

```bash
cp config.example.toml config.toml        # Windows: copy config.example.toml config.toml
```

Lalu edit `config.toml`:

```toml
[general]
invite_code = "QC5MGL"

[solver]
api_key = "<2captcha-key-kalian>"
```

> **Jangan commit `config.toml` asli** — berisi 2captcha key kalian.
> `.gitignore` udah disiapkan. Template lengkap ada di `config.example.toml`
> (semua setting dijelasin per baris), dan referensi penuh di bagian
> **Config lengkap** bawah.

### 4b. (opsional) Git

Kalau project ini mau di-track git, `config.toml` dan `data/` udah otomatis
ke-ignore — cukup:

```bash
git init
git add -A
git commit -m "bai cli"
```

### 5. Siapkan akun

`data/accounts.txt` — satu akun per baris, format `email|password`
(template: `data/accounts.txt.example`):

```
akun1@example.com|password-rahasia-1
akun2@example.com|password-rahasia-2
```

### 6. Siapkan proxy (opsional tapi disarankan)

`data/proxies_working.txt` — satu per baris, format `http://host:port`
(template: `data/proxies_working.txt.example`).
Claim reward dibatesin per IP, jadi proxy rotasi bikin batch lebih tahan.

### 7. Jalankan

Linux / macOS:

```bash
python3 bai_cli.py
```

Windows:

```powershell
python bai_cli.py
```

> Tanpa aktifkan venv pun jalan — script otomatis lompat ke `.venv` project.
> Cara eksplisit: `source .venv/bin/activate` (Linux/macOS) atau
> `.venv\Scripts\activate` (Windows) dulu, baru jalankan.

Pilih menu:

```
[1] Run semua akun
[2] Run tanpa inject 9router
[3] Inject semua key ke 9router
[4] Status akun
[5] Provider 9router
[q] Keluar
```

Atau langsung non-interaktif (Linux/macOS — di Windows ganti `python3` → `python`):

```bash
python3 bai_cli.py run --limit 3
python3 bai_cli.py run --only akun1@example.com
python3 bai_cli.py run --no-inject          # skip inject 9router
```

## Tampilan (TUI rich)

- **Semua dalam box**: banner, menu, kartu per akun, dan tabel — semua Panel.
- **Banner** gradasi dengan animasi *shimmer* (warna judulnya berjalan).
- **Menu** muncul bertahap (stagger reveal).
- **Cardbox per akun**: tiap akun dapat kartu sendiri — spinner animasi,
  log per tahap (login → invite → turnstile → claim → key → inject), progress
  bar dengan efek *wave* `███▓░░ 60%`, border hijau saat sukses / merah saat gagal.
- **Tabel ringkasan** hasil batch + hitungan total/sukses/gagal/key dengan
  angka *count-up*.
- **Sound** (async, gak blocking): beep mulai, sukses, gagal, selesai.
  Dimatiin via `[ui] sound=false` di config.toml atau `BAI_SOUND=0`.
- **Animasi bisa dimatiin**: `[ui] animate=false` (atau `BAI_ANIMATE=0`) —
  tampilan tetap rich, cuma statis.
- **Fallback otomatis**: output di-pipe (`| cat`) atau rich belum terinstall →
  teks polos lengkap. Paksa mode polos dengan `BAI_PLAIN=1`.

Atau panggil script intinya langsung (Linux/macOS; Windows: `.venv\Scripts\python`):

```bash
.venv/bin/python scripts/batch_register_claim.py [--only <email>] [--limit N]
```

## Config lengkap (config.toml)

```toml
[general]
invite_code = "QC5MGL"
sitekey = "0x4AAAAAADKhTSXIozuHjOoF"

[solver]
provider = "2captcha"
api_key = "<2captcha-key>"

[ui]
# TUI modern (rich): banner + cardbox per akun + tabel + sound.
# Otomatis fallback teks polos kalau output di-pipe atau rich belum terinstall.
sound = true            # true = beep ok/fail/start/done (async, gak blocking)
animate = true          # true = shimmer banner, menu reveal, count-up, wave bar
# sound = false         # matiin suara
# animate = false       # matiin animasi (tampilan tetap rich, cuma statis)
# plain = true          # paksa mode teks polos (tanpa rich, meski TTY)

[proxy]
file = "data/proxies_working.txt"
max_tries = 4

[inject]
enabled = true           # key di-inject ke 9router begitu dibuat (per key)
auto_restart = true      # true = kill+relaunch 9router habis batch (perlu biar provider ke-load)
db_paths = []            # kosong = auto-detect per OS (~/.9router/db/data.sqlite, dsb).
                         # bisa satu string (key lama `db_path`) atau daftar path:
                         #   db_paths = ["/home/me/.9router/db/data.sqlite", "D:\\9router\\db\\data.sqlite"]
default_model = "glm-5.3-flash"
base_url = "https://api.b.ai/v1"
prefix = "bai"
numbered = true          # bai-1, bai-2, ... (true) / bai-<email> (false)
```

## Alur per akun

1. Fresh Chrome profile (headless, proxy acak dari pool)
2. Google OAuth login — invite code diisi di modal "Referral Code"
3. Handle interstisial Google otomatis:
   - **Speedbump Workspace** ("I understand") buat akun Workspace baru
   - **Consent OAuth** ("Lanjutkan" / "Continue")
   - Sinyal sukses = popup Google nutup & session cookie `__Secure-authjs.session-token` muncul
4. Buka `/invite` → kalau `claimable` → solve Turnstile (2captcha) → feed token
   via callback `__tsFeed` → klik Claim → verify `claimed:true`
5. Create API key (tRPC `apiKey.createApiKey`, pakai session cookie, no captcha)
6. (opsional) inject key ke 9router → restart gateway sekali di akhir batch

## Retry otomatis

Login Google (speedbump / proxy) bisa **flaky** — kadang klik "I understand"
gak keregister, atau proxy lagi jelek. Script otomatis **retry 3× per akun**
(jeda 20 detik antar percobaan) sebelum pindah ke akun berikutnya.

Override via env kalau perlu (Linux/macOS; Windows: set variabel dulu di cmd/PS):

```bash
BAI_MAX_ATTEMPTS=5 BAI_RETRY_DELAY_S=30 .venv/bin/python scripts/batch_register_claim.py
```

## Debug mode

Kalau ada akun yang gagal dan mau lihat persisnya di mana:

```bash
BAI_DEBUG=1 .venv/bin/python scripts/batch_register_claim.py --only <email>
```

Ini nge-dump **screenshot + isi halaman** tiap langkah login ke `/tmp/bai_debug/`
(`02_loginmodal`, `04_popupopen`, `05_emailnext`, dst.) plus log URL/title/body.
Sangat membantu buat lihat apakah akun nyangkut di speedbump, consent, atau
kredensial salah.

## Troubleshooting

| Gejala | Penyebab / solusi |
|---|---|
| `ModuleNotFoundError: playwright` | Belum install di venv yang dipake. Aktifkan `.venv` lalu `pip install playwright` |
| Tampilan polos (gak ada kartu) | Output di-pipe / `rich` belum terinstall → fallback otomatis. Install: `pip install rich`. Paksa rich di pipe: `BAI_RICH_FORCE=1` |
| Animasi gak muncul (tapi kartu ada) | `[ui] animate=false` atau `BAI_ANIMATE=0` — set `true` kalau mau animasi |
| `error: externally-managed-environment` | Lagi install ke system python — pakai venv (lihat Instalasi) |
| Windows: `.venv\Scripts\Activate.ps1` ditolak | PowerShell block script — jalankan `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, atau pakai CMD `activate.bat` |
| `EOFError: EOF when reading a line` | (sudah di-handle) stdin non-interaktif; kalau mau kasih input, `printf "1\n" \| python3 bai_cli.py` |
| `login: session never established` | Flaky Google login — otomatis retry 3×. Kalau 3× gagal juga, jalankan `BAI_DEBUG=1` buat lihat stuck di mana |
| Browser gak mau jalan di Linux | `python -m playwright install-deps chromium` (install lib sistem) |
| `not_claimable` permanen | Akun daftar **tanpa** invite code — gak bisa diselamatkan, hapus dari `accounts.txt` |
| `solve_failed` / 2captcha error | Saldo 2captcha habis atau key salah — cek `[solver]` di config |
| Provider `bai/*` gak muncul di 9router | 9router cache model pas boot — pastikan `auto_restart=true`, atau inject ulang (menu `[3]`) |

## Catatan penting

- **9router TIDAK live-read**: habis inject harus restart gateway (`auto_restart=true`
  di config) biar provider `bai/*` ke-load.
- **Invite code wajib diisi** pas login (modal "Referral Code"). Kalau enggak, akun
  daftar tanpa invite → `not_claimable` permanen (gak bisa di-bind ulang).
- **Balancing/persyaratan**: signup reward dibatesin per IP → pakai proxy rotasi.
  2captcha dipake solve turnstile (~$0.0015/akun).
- **Log**: setiap percobaan per akun di-append ke `data/batch_result.jsonl`.

## Security

- Key & kredensial jangan di-commit ke sembarang tempat. `config.toml` berisi
  2captcha key; `data/api_keys.json` berisi API key BAI.
- BAI ToS melarang multi-account — pakai tool ini untuk keperluan riset/uji sendiri.
