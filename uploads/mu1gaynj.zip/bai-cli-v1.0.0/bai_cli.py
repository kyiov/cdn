#!/usr/bin/env python3
"""
BAI CLI — interactive auto-register / claim / create-key / inject (9router).

Mekanisme per akun (semua verified):
  register (Google OAuth + invite) -> claim 300k -> create API key -> inject 9router (opsional)

Config di config.toml. Akun di data/accounts.txt (email|pass per baris).

Usage:
  bai_cli.py                    interactive menu
  bai_cli.py run --limit N      non-interactive: register+claim+key+inject N akun
     (--only <email>, --no-inject, --inject)
"""
import argparse, asyncio, hashlib, json, os, re, shutil, sys, random, time, urllib.request

# make scripts/ importable
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "scripts"))

import importlib.util

# ───────────── Rich TUI kit (scripts/ui.py) — fallback otomatis ─────────────
import importlib
ui = importlib.import_module("ui")
say = ui.say

def _ok(text):   return ui.fmt(text, "ok", True)
def _warn(text): return ui.fmt(text, "warn")
def _err(text):  return ui.fmt(text, "err", True)
def _info(text): return ui.fmt(text, "info")
def _dim(text):  return ui.fmt(text, "dim")
def _hdr(text):  return ui.fmt(text, "hdr", True)

# load config.toml (no tomllib dep needed in older py? py3.11+ has tomllib; use tomllib)
try:
    import tomllib
except ModuleNotFoundError:
    tomllib = None

BASE = os.path.dirname(os.path.abspath(__file__))

def find_playwright_py():
    """Locate a python that has playwright installed (needed for the claim flow)."""
    candidates = [
        os.path.join(BASE, ".venv", "bin", "python3"),      # venv project (prioritas)
        "/tmp/playwright-venv/bin/python3",
        os.path.expanduser("~/.venv/bin/python3"),
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    # fallback to system python (hope playwright is there)
    return sys.executable

PLAYWRIGHT_PY = find_playwright_py()

def load_config():
    cfg_path = os.path.join(BASE, "config.toml")
    if os.path.exists(cfg_path):
        with open(cfg_path, "rb") as f:
            return tomllib.load(f) if tomllib else {}
    return {}

def banner():
    ui.banner()

def read_accounts(path):
    """Return list of (email, password)."""
    accts = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or "|" not in line:
                continue
            email, pwd = line.split("|", 1)
            accts.append((email.strip(), pwd.strip()))
    return accts

def read_proxies(path):
    if not os.path.exists(path):
        return []
    with open(path) as f:
        return [l.strip() for l in f if l.strip()]

def menu():
    items = [
        ("1", "Run semua akun"),
        ("2", "Run tanpa inject 9router"),
        ("3", "Inject semua key ke 9router"),
        ("4", "Status akun"),
        ("5", "Provider 9router"),
    ]
    ui.menu_panel(items)

def main():
    # Auto-upgrade: kalau dijalankan pake python tanpa rich (mis. system python3)
    # padahal ada venv ber-rich (sama kaya find_playwright_py), re-exec ke sana
    # biar TUI modern (panel/kartu/sound) tetap tampil — user cukup `python3 bai_cli.py`.
    if sys.stdout.isatty() and not ui.rich_ok and not ui.PLAIN:
        pw = find_playwright_py()
        if pw and os.path.realpath(pw) != os.path.realpath(sys.executable):
            try:
                os.execv(pw, [pw, os.path.abspath(__file__)] + sys.argv[1:])
            except Exception:
                pass  # gagal re-exec → lanjut mode fallback biasa
        elif pw is None or os.path.realpath(pw) == os.path.realpath(sys.executable):
            # gak ada venv / udah di python yang sama → kasih tau user
            print(f"  ⚠ rich belum terinstall di python ini ({sys.executable}).")
            print(f"    TUI fallback ke mode polos. Buat versi penuh:")
            print(f"    python3 -m venv .venv && .venv/bin/pip install playwright rich")

    banner()
    cfg = load_config()
    accounts_path = os.path.join(BASE, "data", "accounts.txt")
    proxies_path = os.path.join(BASE, cfg.get("proxy", {}).get("file", "data/proxies_working.txt"))
    inject_cfg = cfg.get("inject", {})

    if not os.path.exists(accounts_path):
        say("✕ data/accounts.txt tidak ada", color="err")
        say(accounts_path, color="dim")
        return

    accounts = read_accounts(accounts_path)
    say(f"● akun  : {len(accounts)}", color="em")
    if not os.path.exists(proxies_path):
        say(f"⚠ proxy file tidak ada ({proxies_path})", color="warn")
    else:
        say(f"● proxy : {proxies_path}", color="dim")

    # non-interactive fast path
    argv = sys.argv[1:]
    if argv and argv[0] == "run":
        run_all(accounts, cfg, proxies_path, inject_cfg, argv)
        return

    while True:
        menu()
        try:
            choice = input("  > ").strip().lower()
        except EOFError:
            say("EOF received, exiting.", color="dim")
            break
        if choice in ("1", "run"):
            run_all(accounts, cfg, proxies_path, inject_cfg, ["run"])
        elif choice in ("2", "no-inject"):
            run_all(accounts, cfg, proxies_path, inject_cfg, ["run", "--no-inject"])
        elif choice in ("3", "inject"):
            do_inject(cfg, inject_cfg)
        elif choice in ("4", "status"):
            show_status(cfg)
        elif choice in ("5", "providers"):
            show_providers(inject_cfg)
        elif choice in ("q", "quit", "exit"):
            say("bye 👋", color="dim")
            break
        else:
            say("? pilihan gak dikenal", color="warn")

# ---------- load the claim workflow (reuse verified flow) ----------
def _load_claim_module():
    """Import batch_register_claim.py and adapt its globals to our config."""
    import importlib
    sp = os.path.join(BASE, "scripts", "batch_register_claim.py")
    spec = importlib.util.spec_from_file_location("baiclaim", sp)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def _args2flags(argv):
    """Translate CLI flags to the claim module's expected overrides."""
    no_inject = "--no-inject" in argv
    only = None
    limit = None
    if "--only" in argv:
        only = argv[argv.index("--only") + 1]
    if "--limit" in argv:
        limit = int(argv[argv.index("--limit") + 1])
    return only, limit, no_inject

def build_env(cfg, no_inject=False):
    """Map config.toml -> env vars read by batch_register_claim.py."""
    env = os.environ.copy()
    env["BAI_BASE"] = BASE
    env["BAI_ACCOUNTS"] = os.path.join(BASE, "data", "accounts.txt")
    g = cfg.get("general", {})
    env["BAI_INVITE"] = str(g.get("invite_code", "QC5MGL"))
    env["BAI_SITEKEY"] = str(g.get("sitekey", "0x4AAAAAADKhTSXIozuHjOoF"))
    s = cfg.get("solver", {})
    env["BAI_CAPKEY"] = str(s.get("api_key", ""))
    p = cfg.get("proxy", {})
    env["BAI_PROXIES"] = os.path.join(BASE, str(p.get("file", "data/proxies_working.txt")))
    # [inject] -> per-key inject inside the batch subprocess
    import importlib
    inj = importlib.import_module("9router_inject")  # scripts/ on sys.path (L18)
    inj_cfg = cfg.get("inject", {})
    env["BAI_INJECT"] = "1" if (inj_cfg.get("enabled") and not no_inject) else "0"
    env["BAI_INJECT_DB_PATHS"] = os.pathsep.join(inj.resolve_db_paths(inj_cfg))
    env["BAI_INJECT_MODEL"] = str(inj_cfg.get("default_model", "glm-5.3-flash"))
    env["BAI_INJECT_BASE_URL"] = str(inj_cfg.get("base_url", "https://api.b.ai/v1"))
    env["BAI_INJECT_PREFIX"] = str(inj_cfg.get("prefix", "bai"))
    env["BAI_INJECT_NUMBERED"] = "1" if inj_cfg.get("numbered", True) else "0"
    env["BAI_INJECT_AUTO_RESTART"] = "1" if inj_cfg.get("auto_restart", False) else "0"
    return env

def run_all(accounts, cfg, proxies_path, inject_cfg, argv):
    only, limit, no_inject = _args2flags(argv)
    say(f"[run] register+claim+key untuk {len(accounts)} akun...", color="hdr")

    # We inline a simple loop using the claim module, or call it via subprocess.
    # For CLI simplicity, spawn the verified script with our config via env vars.
    import subprocess
    sp = os.path.join(BASE, "scripts", "batch_register_claim.py")
    cmd = [PLAYWRIGHT_PY, sp]
    if only:
        cmd += ["--only", only]
    if limit:
        cmd += ["--limit", str(limit)]
    env = build_env(cfg, no_inject)

    say(f"menjalankan: {' '.join(cmd)}", color="dim")
    subprocess.run(cmd, check=False, env=env)

    # after run, inject if enabled and not skipped
    if inject_cfg.get("enabled") and not no_inject:
        do_inject(cfg, inject_cfg)
    else:
        say("[skip] inject 9router (disabled atau --no-inject)", color="warn")

def do_inject(cfg, inject_cfg):
    import importlib
    import sys as _s
    _s.path.insert(0, os.path.join(BASE, "scripts"))
    inj = importlib.import_module("9router_inject")
    keys_path = os.path.join(BASE, "data", "api_keys.json")
    if not os.path.exists(keys_path):
        say("✕ data/api_keys.json belum ada", color="err")
        return
    keys = inj.read_keys(keys_path)
    paths = inj.resolve_db_paths(inject_cfg)
    say(f"[inject] {len(keys)} key → {len(paths)} 9router DB(s)", color="hdr")
    inj.inject_to_devices(keys, paths,
                          default_model=inject_cfg.get("default_model", "glm-5.3-flash"),
                          base_url=inject_cfg.get("base_url", "https://api.b.ai/v1"),
                          prefix=inject_cfg.get("prefix", "bai"),
                          numbered=inject_cfg.get("numbered", True),
                          auto_restart=inject_cfg.get("auto_restart", False))

def show_status(cfg):
    keys_path = os.path.join(BASE, "data", "api_keys.json")
    accts = read_accounts(os.path.join(BASE, "data", "accounts.txt"))
    if os.path.exists(keys_path):
        with open(keys_path) as f:
            keys = json.load(f)
        key_emails = {k["email"] for k in keys}
    else:
        key_emails = set()
    rows = []
    for email, _ in accts:
        if email in key_emails:
            rows.append(("[ok]●[/ok]", email, "[ok]✓ key[/ok]"))
        else:
            rows.append(("[dim]○[/dim]", email, "[dim]—[/dim]"))
    ui.table(title="STATUS AKUN", cols=(("", "", "left"), ("Email", "white", "left"),
                                        ("Key", "", "right")), rows=rows)

def show_providers(inject_cfg):
    import importlib
    import os
    import sys as _s
    _s.path.insert(0, os.path.join(BASE, "scripts"))
    inj = importlib.import_module("9router_inject")
    say("[providers] 9router yang nodeName=bai", color="hdr")
    all_rows = []
    for db in inj.resolve_db_paths(inject_cfg):
        say(f"-- {db}", color="info")
        rows = inj.list_bai_providers(db)
        if not rows:
            say("   (belum ada)", color="dim")
            continue
        for r in rows:
            all_rows.append((f"[ok]{r['name']}[/ok]", r["model"], f"[dim]{r['key']}[/dim]"))
    ui.provider_table(all_rows)

if __name__ == "__main__":
    main()
