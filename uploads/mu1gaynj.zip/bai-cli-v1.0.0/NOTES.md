# BAI (chat.b.ai) — invite reward claim, VERIFIED WORKING

Status: **claim confirmed successful** on account `user_REDACTED`
(contoh-akun@example.com), 300,000 credits, fulfillment_id 18522.

    {"reward_status":"fulfilled","fulfillment_status":"succeeded",
     "credits_amount":300000,"success":true}

Verified two ways: the claim response itself, and a re-query of
`/invite/my-registration` afterwards showing `claimed: true`.

Working script: `scripts/claim_modal.py`

---

## The flow that works

1. Register via Google OAuth on `https://chat.b.ai/chat` with a referral code
   (`QC5MGL`). Callback: `POST /api/auth/callback/google-gis`.
2. Go to **`https://chat.b.ai/invite`** — NOT `/chat`. The claim UI only
   exists on `/invite`, `/referral`, `/me`, `/profile`, `/rewards`.
3. Click `Claim Free Credits` -> the gift modal opens with a **disabled**
   `Claim` button and a Turnstile widget.
4. Solve Turnstile and fire the widget's **callback**. The button enables.
5. Click `Claim` -> the app POSTs and credits land.

## The real claim request

    POST https://api.b.ai/api/activity/invite/registration-reward/claim
    X-Ainft-Auth-Token: Bearer <apiAccessToken>
    Content-Type: application/json

    {"signup_bonus": {
       "type": "oauth:google",
       "turnstile_token": "<turnstile token, ~837 chars>",
       "encrypted_token": "U2FsdGVkX1+k8yaO0fvo..."
    }}

Captured verbatim from the live app — not reconstructed.

Two things worth knowing:

- **`encrypted_token` IS the "signature".** Posting `{}` (or `{confirm:true}`,
  `{reward_order_id:N}`, `{registration_reward:{...}}`) returns HTTP 200 with
  `{"message":"signature verification is required","success":false}`. All four
  guesses were rejected; only the real payload works. The value is a CryptoJS
  AES blob (`U2FsdGVkX1+` = "Salted__" base64) produced during the Google GIS
  login, so it can't be forged offline — you need a real sign-in.
- **`browser_signals` and `client_fingerprint_hash` are NOT sent.** The bundle
  defines them but the live request omits them entirely. Optional.

Rejected attempts do not consume the reward — state stays
`claimable: true`, so probing is safe.

## Turnstile — 2captcha, and it genuinely matters

Sitekey `0x4AAAAAADKhTSXIozuHjOoF`, `action: null`, `cData: null`.

Proof the bypass is load-bearing (button dump around the token feed):

    pre-token :  [6] disabled=True   'Claim'
    post-token:  [6] disabled=False  'Claim'

Solver comparison, measured:

    2captcha  TurnstileTaskProxyless   5-10s      <- use this
    NopeCHA   /token/ turnstile        5+ min, never returned

    POST https://api.2captcha.com/createTask
    {"clientKey":"...","task":{"type":"TurnstileTaskProxyless",
     "websiteURL":"https://chat.b.ai/invite",
     "websiteKey":"0x4AAAAAADKhTSXIozuHjOoF"}}
    poll POST https://api.2captcha.com/getTaskResult

Cost ~$0.001/solve. Balance check: `getBalance`.

### The token MUST go through the widget callback

Setting `input[name=cf-turnstile-response]` alone does nothing — React never
notices and the button stays disabled. Stub `window.turnstile` in an init
script (before app JS), capture `params.callback` in `render()`, then call it
with the solved token:

```js
Object.defineProperty(window, 'turnstile', {
  configurable: true, get() { return api; }, set(v) {}   // block overwrite
});
```

`scripts/claim_modal.py` has the full hook.

### Clicking Claim: use the button index

`button:has-text('Claim')` matches `Claim Free Credits` first and reopens the
modal instead of submitting. Enumerate buttons, find the one whose text is
exactly `Claim` and is not disabled, then click by index:

```js
document.querySelectorAll('button')[i].click()
```

## Auth

`apiAccessToken` comes from tRPC `user.getUserState`
(`result.data.json.apiAccessToken`), sent as `X-Ainft-Auth-Token: Bearer …`
— not a cookie, not `Authorization`. Refresh on 401 by re-querying.
Session cookie: `__Secure-authjs.session-token`.

## Two different rewards — don't confuse them

`/invite/my-registration` reports both:

    registration_reward   300,000 credits for using an invite code  <- claimable
    signup_bonus          the standalone new-account bonus

Measured on a **brand-new** account: `signup_bonus.eligible` was already
`false` at registration, while `registration_reward` was claimable. So they
appear to be mutually exclusive — registering with a referral code puts you
on the registration_reward track. Age of the account is not the factor.

## Endpoints

    POST /api/activity/invite/registration-reward/claim
    GET  /api/activity/invite/my-registration     state: claimable/claimed/eligible
    GET  /api/activity/invite/center              coin balance, rebate, exchange rate
    GET  /api/activity/invite/code                your own invite code
    POST /api/activity/coin/exchange              {coin_amount, request_id}
    GET  /api/activity/campaigns/<campaign>/codes/<CODE>/validate?entry=registration

Base URL per hostname (`teamApiUrl`): chat.b.ai -> https://api.b.ai,
chat-dev.b.ai -> https://api-dev.b.ai, chat-pre.* -> https://api-stg.b.ai.
Path = `/api/activity` + endpoint.

## Anti-abuse

From migration SQL in the bundle:

    t_signup_bonus_ip_limits (ip, created_at)
    idx_signup_bonus_ip_limits_ip_created_at

Signup bonus is rate-limited per IP — rotating proxies matters more than
fingerprint spoofing for repeat runs. Note `webdriver` appears in the
`browser_signals` schema, though the live claim doesn't send it.

## Pitfalls

- **Proxies from `data/proxies_working.txt` broke page load.** With
  `http://192.186.131.217:8800` the app rendered no `Log in` button at all;
  direct connection worked immediately. Always dump `document.title` +
  visible buttons before concluding a selector is missing.
- Claim UI is not on `/chat`. Use `/invite`.
- Don't close the login modal before OAuth finishes — COOP blocks the GIS
  callback and the session never establishes.
- `shutil.copytree` on a Chrome profile fails on `Singleton*` lock sockets;
  copy with `ignore=shutil.ignore_patterns("Singleton*")`.
- Reading the client bundle alone was misleading: `claimRegistrationReward({})`
  really does serialise to `{}`, but the server rejects it. The actual caller
  lives in a lazy chunk; recording the live request is the reliable route.

## Files

    scripts/claim_modal.py     WORKING end-to-end claim (turnstile + click)
    scripts/bai_v8.py          register a fresh account, records network
    scripts/explore_claim.py   route/payload probing
    scripts/recon_invite.py    read-only state check
    scripts/cap2_test.py       2captcha balance + solve test
    data/modal_posts.json      captured claim POST + result
    data/v8_network.jsonl      full network log of registration
    js/chunks/                 132 JS chunks (all from webpack manifest)

---

# BAI API key — VERIFIED (auto-create in batch)

Endpoint (captured from live UI, not guessed):

    POST https://chat.b.ai/trpc/lambda/apiKey.createApiKey?batch=1
    Cookie: __Secure-authjs.session-token=<BAI session cookie>
    Body:   {"0":{"json":{"group":"default","name":"<key name>"}}}

    -> Resp tRPC envelope, .result.data.json.key = the "sk-..." full key
       .result.data.json.maskedKey = display form
       .result.data.json.group = "default" (46 models, official access)

List:
    GET https://chat.b.ai/trpc/lambda/apiKey.getApiKeys

Notes:
- NO turnstile/captcha needed. Just the session cookie.
- Body is raw tRPC batch format: single object {"0":{...}} (not array).
- group "default" = 46 models, direct official API access, max availability.
- Session cookie comes from BAI login (OAuth). The batch script grabs it via
  browser context cookies and POSTs it.

## Verified API usage (glm-5.3-flash)

    POST https://api.b.ai/v1/chat/completions
    Authorization: Bearer sk-...
    {"model":"glm-5.3-flash","messages":[{"role":"user","content":"hi"}]}

Works. key[0] and key[6] both returned "ok". Non-issue: one earlier attempt
looked like a non-JSON parse fail but the raw body was valid JSON.

## Batch script (all-in-one: register + claim + api key)

    scripts/batch_register_claim.py
        reads data/accounts.txt  (email|password lines)
        --only <email>   single
        --limit N        first N
        --apikey-only    skip login/claim, just make keys (reserved)

    Per account: fresh profile -> Google OAuth login (handles accountchooser)
    -> /invite -> claim 300k -> create API key via tRPC.
    Results -> data/batch_result.jsonl
    Keys    -> data/api_keys.json  (deduped by email)

## KEY PITFALL for Google login via proxy

When a Google account was PREVIOUSLY used from the same proxy/IP, Google
SHOWS the account chooser ("Pilih akun") instead of the email form. The popup
URL is accounts.google.com/v3/signin/accountchooser... and there is NO
input#identifierId. The old code waited for that input and timed out
("session never established").

FIX: detect accountchooser (url contains "accountchooser" or [data-email]
present) -> click the matching account (or first account) -> that's enough,
skip password. This is what lets a batch re-login an already-used account.

File: scripts/api_key_notes.md (this section)

---

# 9router inject — IMPORTANT behavior discovered

9router stores upstreams in `~/.9router/db/data.sqlite` -> table `providerConnections`.
Each row: provider = `openai-compatible-chat-<uuid>`, authType=apikey, name=label,
data = JSON with {defaultModel, apiKey, providerSpecificData:{prefix, apiType, baseUrl, nodeName, ...}}.

## CRITICAL: 9router does NOT live-read new providers
Verified: injected a new provider row, then GET http://127.0.0.1:20128/v1/models
-> it did NOT list the new `bai` prefix (model list cached at gateway startup).
`providerConnections` rows are loaded into memory when the gateway boots.
=> After inserting rows you MUST restart the gateway for it to pick them up.

## Restart method
Gateway runs as:
    /usr/bin/node /usr/lib/node_modules/9router/cli.js --tray --skip-update   (pid ~2142)
    -> spawns `next-server (v16.3.4)` (pid ~2520), both are child processes.
No systemd unit. Restart = kill those PIDs (SIGTERM) then relaunch the node cli.
`scripts/9router_inject.py -> restart_9router()` does this (auto_restart=True in config).

## Why inject at all?
BAI keys work on api.b.ai/v1 (OpenAI-compatible). 9router gateway listens on 127.0.0.1:20128
and maps upstream providerConnections to model ids as `<prefix>/<model>`.
So a BAI key -> provider prefix `bai` -> model ids like `bai/claude-opus-5`, `bai/glm-5.3-flash`.

## Endpoint to confirm models after restart
    curl http://127.0.0.1:20128/v1/models   -> should then list `bai/...`

## Config (config.toml [inject])
    enabled=false, auto_restart=false, default_model="glm-5.3-flash",
    db_path, base_url="https://api.b.ai/v1", prefix="bai", numbered=true

---

# FINAL VERIFIED FLOW (headless) — 2026-09-04

## Register + claim + API key — VERIFIED WORKING, HEADLESS
Jalankan (browser TIDAK muncul; headless=True):
    /tmp/playwright-venv/bin/python3 scripts/batch_register_claim.py [--only <email>]
    or all accounts in data/accounts.txt

## KEY FIXES (these are what made it reliable)
1. **headless=True** — browser never shows (was headless=False).
2. **google_login simplified** — removed accountchooser/speedbump blocks that
   flaked. Correct sequence for a fresh Google account:
     invite fill -> Google popup -> identifier(email) -> Next -> password -> Next
     -> consent click (Lanjutkan/Continue/Allow) -> poll /api/auth/session via fetch.
   session detection used fetch('/api/auth/session'), NOT the "Log in" button
   disappearing (that flakes in headless).
3. **invite_code MUST be filled in the login modal** ("Referral Code (Optional)"
   button -> input[placeholder='Enter referral code']). This ensures the account
   BINDS to the invite on the google-gis callback, so registration_reward becomes
   bound + claimable. WITHOUT this the account registers unbound (not_claimable).
   Verified endpoint: POST /api/auth/callback/google-gis?code=..&invite_code=QC5MGL&..

## RESULTS
- 13 BAI accounts have 300k credits each (3.9M total), each with an API key:
  [7 akun batch lama]
  + [6 akun batch baru, claimed+key]
- <contoh-akun-gagal> = NOT salvageable (registered without invite in an old batch ->
  permanently not_claimable). Remove from accounts.txt or keep as known-fail.
- 2captcha balance: ~$0.02 dipake per run.

## 9router inject — VERIFIED WORKING
Injected 13 BAI keys into 9router (bai-1..bai-13, default_model=glm-5.3-flash).
After restart the gateway loaded all 13 as providers -> 46 `bai/*` models
visible at GET http://127.0.0.1:20128/v1/models.
Confirmed: 9router is NOT live-read — MUST restart (auto_restart in config) to
pick up new providers.

## CLI (bai_cli.py) — INTERACTIVE
- menu [1] run all (register+claim+key) then auto-inject IF [inject].enabled=true
- menu [2] run all, skip inject
- menu [3] inject existing keys to 9router manually
- menu [4] status (email vs api_key)
- menu [5] show 9router bai providers
- menu [q] quit
- Config in config.toml; accounts in data/accounts.txt (email|pass).

## inject on/off (config.toml [inject])
- enabled = false  (run auto-inject OFF by default)
- auto_restart = false (default; set true to kill+relaunch 9router after inject,
  needed because gateway is NOT live-read)

# UPDATE — inject 9router DIBATALKAN (2026-09-04)
> SUPERSEDED — lihat entry "inject per-key + multi-OS" di bawah (schema dua tabel
> sudah terverifikasi & inject re-enabled 2026-09-04).
Fitur "inject key BAI ke 9router" dibatalkan & semuanya di-rollback:
- Semua provider `bai-*` DIHAPUS dari 9router (providerConnections + providerNodes).
- `/v1/models` balik baseline (684 model, no bai/*).
- config.toml [inject].enabled=false.

Kenapa dibatalin: inject asal-asalan ke DB. 9router butuh schema kompleks
(providerNodes NODE + providerConnections linked), nggak cuma insert 1 tabel.
Sampai dipahami bener, inject off — key BAI dipakai langsung via api.b.ai/v1.

# UPDATE — inject per-key + multi-OS (2026-09-04)

Fitur inject 9router di-aktifkan ulang + upgrade:

- **Per-key inject**: `[inject].enabled=true` -> `bai_cli.py` oper env `BAI_INJECT_*`
  ke `batch_register_claim.py`; tiap key di-inject ke 9router BEGITU dibuat
  (hook `_inject_key` setelah `save_api_key`), restart gateway cuma SEKALI di
  akhir batch (`INJECT_AUTO_RESTART` + `INJECTED_ANY`).
- **Multi-OS path**: `config.toml [inject] db_paths = []` (kosong = auto-detect).
  `9router_inject.detect_db_path()`: Linux `~/.9router/db/data.sqlite` /
  `$XDG_DATA_HOME/9router/...`; macOS `~/Library/Application Support/9router/...`;
  Windows `%USERPROFILE%\.9router\...` / `%APPDATA%` / `%LOCALAPPDATA%`.
  `resolve_db_paths()` normalisasi `db_paths` (string/list) atau `db_path` lama.
- **`inject_to_devices()`**: loop inject ke semua path lokal, restart gateway
  sekali di akhir kalau ada insert. Dedupe per apiKey — aman diulang.
- **Fix numbering**: `inject()` sekarang lanjut dari jumlah row di node
  (`bai-14`, `bai-15`, ...) — per-key inject nggak nge-reset ke `bai-1`.
- **`restart_9router()` cross-platform**: `node` via `shutil.which`, `cli.js`
  via kandidat dir per OS; di Windows print hint restart manual (pgrep gak ada).
- **Windows**: inject DB jalan normal (pure sqlite3); restart harus manual.

Verified 2026-09-04 (non-destruktif, copy DB via sqlite backup API):
- detect/resolve semua varian path OK.
- inject ke copy: `sk-FAKE-1` -> bai-14, ulang -> `already injected`,
  `sk-FAKE-2` -> bai-15, path gak ada -> `db not found` tanpa crash.
- Hook batch di venv playwright: `_inject_key` -> bai-16.
- Menu [3] live: 13 key -> semua `already injected`, 0 insert, gateway tetap jalan.
